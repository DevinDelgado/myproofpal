import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { proof_id, share_token, author_name, body, x, y, file_id } = await req.json();

    if (!proof_id || !share_token || !author_name || !body) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (String(body).trim().length === 0 || String(author_name).trim().length === 0) {
      return new Response(JSON.stringify({ error: "Empty body or author name" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: proof, error: fetchError } = await supabase
      .from("proofs")
      .select("id, share_token")
      .eq("id", proof_id)
      .maybeSingle();

    if (fetchError || !proof) {
      return new Response(JSON.stringify({ error: "Proof not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (proof.share_token !== share_token) {
      return new Response(JSON.stringify({ error: "Invalid share token" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: inserted, error: insertError } = await supabase
      .from("annotations")
      .insert({
        proof_id,
        file_id: file_id ?? null,
        author_id: null,
        author_name: String(author_name).slice(0, 100),
        body: String(body).slice(0, 5000),
        x: x ?? null,
        y: y ?? null,
      })
      .select()
      .single();

    if (insertError) {
      return new Response(JSON.stringify({ error: insertError.message }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ annotation: inserted }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
