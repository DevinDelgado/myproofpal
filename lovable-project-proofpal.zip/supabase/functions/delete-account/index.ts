import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const userClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = userData.user.id;
    const admin = createClient(supabaseUrl, serviceKey);

    // Collect all storage paths for this user's proofs
    const { data: files } = await admin
      .from("proof_files")
      .select("image_path, proofs!inner(owner_id)")
      .eq("proofs.owner_id", userId);
    const { data: proofsList } = await admin
      .from("proofs")
      .select("image_path")
      .eq("owner_id", userId);

    const paths = [
      ...((files ?? []) as Array<{ image_path: string }>).map((f) => f.image_path),
      ...((proofsList ?? []) as Array<{ image_path: string }>).map((p) => p.image_path),
    ].filter(Boolean);
    if (paths.length > 0) {
      await admin.storage.from("proofs").remove(paths);
    }

    // Delete db rows owned by user
    const { data: proofIds } = await admin.from("proofs").select("id").eq("owner_id", userId);
    const ids = (proofIds ?? []).map((p: { id: string }) => p.id);
    if (ids.length > 0) {
      await admin.from("annotations").delete().in("proof_id", ids);
      await admin.from("proof_files").delete().in("proof_id", ids);
      await admin.from("proofs").delete().in("id", ids);
    }
    await admin.from("profiles").delete().eq("id", userId);

    // Delete the auth user
    const { error: delErr } = await admin.auth.admin.deleteUser(userId);
    if (delErr) {
      return new Response(JSON.stringify({ error: delErr.message }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
