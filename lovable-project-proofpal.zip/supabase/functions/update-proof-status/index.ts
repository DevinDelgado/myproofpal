import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { proof_id, share_token, status, actor_name, file_id } = await req.json();

    if (!proof_id || !share_token || !status) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!["approved", "changes_requested", "pending"].includes(status)) {
      return new Response(JSON.stringify({ error: "Invalid status" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: proof, error: fetchError } = await supabase
      .from("proofs")
      .select("id, share_token, status")
      .eq("id", proof_id)
      .maybeSingle();

    if (fetchError || !proof) {
      return new Response(JSON.stringify({ error: "Proof not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (proof.share_token !== share_token) {
      return new Response(JSON.stringify({ error: "Invalid share token" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const name = (typeof actor_name === "string" && actor_name.trim().slice(0, 80)) || "Reviewer";
    const now = new Date().toISOString();

    // Per-file status update
    if (file_id) {
      const { data: fileRow, error: fileErr } = await supabase
        .from("proof_files")
        .select("id, proof_id, status, position")
        .eq("id", file_id)
        .maybeSingle();

      if (fileErr || !fileRow || fileRow.proof_id !== proof_id) {
        return new Response(JSON.stringify({ error: "File not found" }), {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const { error: updErr } = await supabase
        .from("proof_files")
        .update({ status, status_changed_by: name, status_changed_at: now })
        .eq("id", file_id);

      if (updErr) {
        return new Response(JSON.stringify({ error: updErr.message }), {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      await supabase.from("proof_events").insert({
        proof_id,
        actor_name: name,
        event_type: "file_status_changed",
        details: { file_id, from: fileRow.status, to: status, position: fileRow.position, via: "share" },
      });

      return new Response(JSON.stringify({ success: true, file_id, status }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Legacy: proof-level status (still supported)
    const { error: updateError } = await supabase
      .from("proofs")
      .update({ status, status_changed_by: name, status_changed_at: now })
      .eq("id", proof_id);

    if (updateError) {
      return new Response(JSON.stringify({ error: updateError.message }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    await supabase.from("proof_events").insert({
      proof_id,
      actor_name: name,
      event_type: "status_changed",
      details: { from: proof.status, to: status, via: "share" },
    });

    return new Response(JSON.stringify({ success: true, status }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
