import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { proof_id, share_token } = await req.json();

    if (!proof_id || !share_token) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: proof, error: fetchError } = await supabase
      .from("proofs")
      .select("*")
      .eq("id", proof_id)
      .maybeSingle();

    if (fetchError || !proof) {
      return new Response(JSON.stringify({ error: "Proof not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (proof.share_token !== share_token) {
      return new Response(JSON.stringify({ error: "Invalid share token" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: annotations } = await supabase
      .from("annotations")
      .select("*")
      .eq("proof_id", proof_id)
      .order("created_at", { ascending: true });

    const { data: files } = await supabase
      .from("proof_files")
      .select("id, image_url, image_path, position, created_at, status, status_changed_by, status_changed_at")
      .eq("proof_id", proof_id)
      .order("position", { ascending: true })
      .order("created_at", { ascending: true });

    const { data: events } = await supabase
      .from("proof_events")
      .select("id, actor_name, event_type, details, created_at")
      .eq("proof_id", proof_id)
      .order("created_at", { ascending: false });

    return new Response(
      JSON.stringify({ proof, annotations: annotations ?? [], files: files ?? [], events: events ?? [] }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
