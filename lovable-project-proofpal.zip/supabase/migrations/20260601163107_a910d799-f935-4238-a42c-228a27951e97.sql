
CREATE TABLE public.proof_events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  proof_id UUID NOT NULL REFERENCES public.proofs(id) ON DELETE CASCADE,
  actor_id UUID,
  actor_name TEXT NOT NULL,
  event_type TEXT NOT NULL,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_proof_events_proof_id ON public.proof_events(proof_id, created_at);

GRANT SELECT, INSERT ON public.proof_events TO authenticated;
GRANT ALL ON public.proof_events TO service_role;

ALTER TABLE public.proof_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners can view events on their proofs"
ON public.proof_events
FOR SELECT
USING (EXISTS (SELECT 1 FROM public.proofs p WHERE p.id = proof_events.proof_id AND p.owner_id = auth.uid()));

CREATE POLICY "Owners can insert events on their proofs"
ON public.proof_events
FOR INSERT
WITH CHECK (EXISTS (SELECT 1 FROM public.proofs p WHERE p.id = proof_events.proof_id AND p.owner_id = auth.uid()));
