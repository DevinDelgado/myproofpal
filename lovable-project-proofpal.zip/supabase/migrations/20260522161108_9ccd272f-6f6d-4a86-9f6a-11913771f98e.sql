
-- 1. proof_files table
CREATE TABLE public.proof_files (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  proof_id UUID NOT NULL REFERENCES public.proofs(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  image_path TEXT NOT NULL,
  position INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

CREATE INDEX idx_proof_files_proof_id ON public.proof_files(proof_id);

ALTER TABLE public.proof_files ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners can view files of their proofs"
ON public.proof_files FOR SELECT
USING (EXISTS (SELECT 1 FROM public.proofs p WHERE p.id = proof_files.proof_id AND p.owner_id = auth.uid()));

CREATE POLICY "Owners can insert files on their proofs"
ON public.proof_files FOR INSERT
WITH CHECK (EXISTS (SELECT 1 FROM public.proofs p WHERE p.id = proof_files.proof_id AND p.owner_id = auth.uid()));

CREATE POLICY "Owners can update files on their proofs"
ON public.proof_files FOR UPDATE
USING (EXISTS (SELECT 1 FROM public.proofs p WHERE p.id = proof_files.proof_id AND p.owner_id = auth.uid()));

CREATE POLICY "Owners can delete files on their proofs"
ON public.proof_files FOR DELETE
USING (EXISTS (SELECT 1 FROM public.proofs p WHERE p.id = proof_files.proof_id AND p.owner_id = auth.uid()));

-- 2. file_id on annotations
ALTER TABLE public.annotations
  ADD COLUMN file_id UUID REFERENCES public.proof_files(id) ON DELETE CASCADE;

CREATE INDEX idx_annotations_file_id ON public.annotations(file_id);

-- 3. Backfill: one proof_files row per existing proof, and link existing annotations to it
INSERT INTO public.proof_files (proof_id, image_url, image_path, position, created_at)
SELECT id, image_url, image_path, 0, created_at FROM public.proofs;

UPDATE public.annotations a
SET file_id = pf.id
FROM public.proof_files pf
WHERE pf.proof_id = a.proof_id AND a.file_id IS NULL;
