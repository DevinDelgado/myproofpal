
REVOKE EXECUTE ON FUNCTION public.is_proof_collaborator(uuid, uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_proof_collaborator(uuid, uuid) TO authenticated, service_role;
