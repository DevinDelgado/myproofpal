
DROP POLICY IF EXISTS "Anyone can insert annotations on existing proofs" ON public.annotations;

CREATE POLICY "Owners can insert annotations on their proofs"
ON public.annotations
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.proofs p
    WHERE p.id = annotations.proof_id AND p.owner_id = auth.uid()
  )
  AND length(body) > 0
  AND length(author_name) > 0
);
