
-- Per-file approval status
ALTER TABLE public.proof_files
  ADD COLUMN IF NOT EXISTS status public.proof_status NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS status_changed_by text,
  ADD COLUMN IF NOT EXISTS status_changed_at timestamptz;

-- Aggregate file statuses into the parent proof
CREATE OR REPLACE FUNCTION public.recompute_proof_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_proof_id uuid;
  v_total int;
  v_approved int;
  v_changes int;
  v_new public.proof_status;
  v_last_actor text;
  v_last_at timestamptz;
BEGIN
  v_proof_id := COALESCE(NEW.proof_id, OLD.proof_id);

  SELECT COUNT(*),
         COUNT(*) FILTER (WHERE status = 'approved'),
         COUNT(*) FILTER (WHERE status = 'changes_requested')
    INTO v_total, v_approved, v_changes
  FROM public.proof_files
  WHERE proof_id = v_proof_id;

  IF v_total = 0 THEN
    v_new := 'pending';
  ELSIF v_changes > 0 THEN
    v_new := 'changes_requested';
  ELSIF v_approved = v_total THEN
    v_new := 'approved';
  ELSE
    v_new := 'pending';
  END IF;

  SELECT status_changed_by, status_changed_at
    INTO v_last_actor, v_last_at
  FROM public.proof_files
  WHERE proof_id = v_proof_id AND status_changed_at IS NOT NULL
  ORDER BY status_changed_at DESC
  LIMIT 1;

  UPDATE public.proofs
     SET status = v_new,
         status_changed_by = COALESCE(v_last_actor, status_changed_by),
         status_changed_at = COALESCE(v_last_at, status_changed_at)
   WHERE id = v_proof_id;

  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trg_recompute_proof_status ON public.proof_files;
CREATE TRIGGER trg_recompute_proof_status
AFTER INSERT OR UPDATE OF status OR DELETE ON public.proof_files
FOR EACH ROW EXECUTE FUNCTION public.recompute_proof_status();

-- Backfill existing rows: treat current proof status as default for files
UPDATE public.proof_files pf
SET status = p.status
FROM public.proofs p
WHERE pf.proof_id = p.id AND pf.status = 'pending' AND p.status <> 'pending';
