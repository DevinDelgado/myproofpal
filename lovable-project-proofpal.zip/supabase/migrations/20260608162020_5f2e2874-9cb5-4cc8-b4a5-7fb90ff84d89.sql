
REVOKE ALL ON FUNCTION public.notify_proof_recipients(uuid, uuid, text, text, text) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.notify_on_annotation() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.notify_on_file_status() FROM PUBLIC, anon, authenticated;
