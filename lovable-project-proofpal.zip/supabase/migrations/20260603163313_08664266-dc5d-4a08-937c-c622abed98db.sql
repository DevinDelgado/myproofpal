
REVOKE EXECUTE ON FUNCTION public.recompute_proof_status() FROM PUBLIC, anon, authenticated;
