
-- Profiles table
CREATE TABLE public.profiles (
  id UUID NOT NULL PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email TEXT,
  display_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Profiles are viewable by everyone"
  ON public.profiles FOR SELECT USING (true);

CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, display_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'display_name', NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1))
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Proof status enum
CREATE TYPE public.proof_status AS ENUM ('pending', 'approved', 'changes_requested');

-- Proofs table
CREATE TABLE public.proofs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  owner_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  image_url TEXT NOT NULL,
  image_path TEXT NOT NULL,
  status public.proof_status NOT NULL DEFAULT 'pending',
  share_token UUID NOT NULL DEFAULT gen_random_uuid() UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.proofs ENABLE ROW LEVEL SECURITY;

-- Owners full access
CREATE POLICY "Owners can view their proofs"
  ON public.proofs FOR SELECT USING (auth.uid() = owner_id);

CREATE POLICY "Anyone can view proofs (for share links)"
  ON public.proofs FOR SELECT USING (true);

CREATE POLICY "Users can insert their own proofs"
  ON public.proofs FOR INSERT WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Owners can update their proofs"
  ON public.proofs FOR UPDATE USING (auth.uid() = owner_id);

CREATE POLICY "Owners can delete their proofs"
  ON public.proofs FOR DELETE USING (auth.uid() = owner_id);

-- Annotations table
CREATE TABLE public.annotations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  proof_id UUID NOT NULL REFERENCES public.proofs(id) ON DELETE CASCADE,
  author_id UUID REFERENCES auth.users ON DELETE SET NULL,
  author_name TEXT NOT NULL,
  body TEXT NOT NULL,
  x NUMERIC,
  y NUMERIC,
  resolved BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.annotations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view annotations"
  ON public.annotations FOR SELECT USING (true);

CREATE POLICY "Anyone can insert annotations"
  ON public.annotations FOR INSERT WITH CHECK (true);

CREATE POLICY "Proof owners can update annotations"
  ON public.annotations FOR UPDATE USING (
    EXISTS (SELECT 1 FROM public.proofs p WHERE p.id = proof_id AND p.owner_id = auth.uid())
  );

CREATE POLICY "Proof owners or comment author can delete annotations"
  ON public.annotations FOR DELETE USING (
    auth.uid() = author_id OR
    EXISTS (SELECT 1 FROM public.proofs p WHERE p.id = proof_id AND p.owner_id = auth.uid())
  );

-- Updated_at trigger
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER proofs_set_updated_at
  BEFORE UPDATE ON public.proofs
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Storage bucket
INSERT INTO storage.buckets (id, name, public) VALUES ('proofs', 'proofs', true);

CREATE POLICY "Public read access for proofs"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'proofs');

CREATE POLICY "Authenticated users can upload proofs"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'proofs' AND auth.role() = 'authenticated');

CREATE POLICY "Users can update their own proof files"
  ON storage.objects FOR UPDATE
  USING (bucket_id = 'proofs' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their own proof files"
  ON storage.objects FOR DELETE
  USING (bucket_id = 'proofs' AND auth.uid()::text = (storage.foldername(name))[1]);
