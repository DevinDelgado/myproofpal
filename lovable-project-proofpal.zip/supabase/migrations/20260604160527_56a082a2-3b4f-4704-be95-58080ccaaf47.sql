
-- Collaborators table
CREATE TABLE public.proof_collaborators (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  proof_id uuid NOT NULL REFERENCES public.proofs(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  invited_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (proof_id, user_id)
);

GRANT SELECT, INSERT, DELETE ON public.proof_collaborators TO authenticated;
GRANT ALL ON public.proof_collaborators TO service_role;

ALTER TABLE public.proof_collaborators ENABLE ROW LEVEL SECURITY;

-- Helper: avoid recursion when used in other tables' policies
CREATE OR REPLACE FUNCTION public.is_proof_collaborator(_proof_id uuid, _user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.proof_collaborators
    WHERE proof_id = _proof_id AND user_id = _user_id
  );
$$;

-- Policies on proof_collaborators
CREATE POLICY "Owner or self can view collaborators"
  ON public.proof_collaborators FOR SELECT
  USING (
    user_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.proofs p WHERE p.id = proof_id AND p.owner_id = auth.uid())
  );

CREATE POLICY "Owner can add collaborators"
  ON public.proof_collaborators FOR INSERT
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.proofs p WHERE p.id = proof_id AND p.owner_id = auth.uid())
  );

CREATE POLICY "Owner can remove collaborators"
  ON public.proof_collaborators FOR DELETE
  USING (
    EXISTS (SELECT 1 FROM public.proofs p WHERE p.id = proof_id AND p.owner_id = auth.uid())
    OR user_id = auth.uid()
  );

-- Extend access on proofs
CREATE POLICY "Collaborators can view proofs"
  ON public.proofs FOR SELECT
  USING (public.is_proof_collaborator(id, auth.uid()));

CREATE POLICY "Collaborators can update proofs"
  ON public.proofs FOR UPDATE
  USING (public.is_proof_collaborator(id, auth.uid()))
  WITH CHECK (public.is_proof_collaborator(id, auth.uid()));

-- proof_files
CREATE POLICY "Collaborators can view files"
  ON public.proof_files FOR SELECT
  USING (public.is_proof_collaborator(proof_id, auth.uid()));

CREATE POLICY "Collaborators can insert files"
  ON public.proof_files FOR INSERT
  WITH CHECK (public.is_proof_collaborator(proof_id, auth.uid()));

CREATE POLICY "Collaborators can update files"
  ON public.proof_files FOR UPDATE
  USING (public.is_proof_collaborator(proof_id, auth.uid()))
  WITH CHECK (public.is_proof_collaborator(proof_id, auth.uid()));

CREATE POLICY "Collaborators can delete files"
  ON public.proof_files FOR DELETE
  USING (public.is_proof_collaborator(proof_id, auth.uid()));

-- annotations
CREATE POLICY "Collaborators can view annotations"
  ON public.annotations FOR SELECT
  USING (public.is_proof_collaborator(proof_id, auth.uid()));

CREATE POLICY "Collaborators can insert annotations"
  ON public.annotations FOR INSERT
  WITH CHECK (
    public.is_proof_collaborator(proof_id, auth.uid())
    AND length(body) > 0
    AND length(author_name) > 0
  );

CREATE POLICY "Collaborators can update annotations"
  ON public.annotations FOR UPDATE
  USING (public.is_proof_collaborator(proof_id, auth.uid()));

-- proof_events
CREATE POLICY "Collaborators can view events"
  ON public.proof_events FOR SELECT
  USING (public.is_proof_collaborator(proof_id, auth.uid()));

CREATE POLICY "Collaborators can insert events"
  ON public.proof_events FOR INSERT
  WITH CHECK (public.is_proof_collaborator(proof_id, auth.uid()));
