
CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  proof_id uuid REFERENCES public.proofs(id) ON DELETE CASCADE,
  proof_title text,
  type text NOT NULL CHECK (type IN ('approved','changes_requested','comment')),
  message text NOT NULL,
  actor_name text,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_notifications_user ON public.notifications(user_id, read, created_at DESC);

GRANT SELECT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view their own notifications"
  ON public.notifications FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users update their own notifications"
  ON public.notifications FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users delete their own notifications"
  ON public.notifications FOR DELETE
  USING (auth.uid() = user_id);

ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
ALTER TABLE public.notifications REPLICA IDENTITY FULL;

-- Helper: recipients for a proof (owner + assignees), excluding optional actor
CREATE OR REPLACE FUNCTION public.notify_proof_recipients(
  _proof_id uuid,
  _actor_id uuid,
  _type text,
  _message text,
  _actor_name text
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_title text;
BEGIN
  SELECT title INTO v_title FROM public.proofs WHERE id = _proof_id;

  INSERT INTO public.notifications (user_id, proof_id, proof_title, type, message, actor_name)
  SELECT u, _proof_id, v_title, _type, _message, _actor_name
  FROM (
    SELECT owner_id AS u FROM public.proofs WHERE id = _proof_id
    UNION
    SELECT user_id AS u FROM public.proof_assignees WHERE proof_id = _proof_id
  ) r
  WHERE r.u IS NOT NULL AND (_actor_id IS NULL OR r.u <> _actor_id);
END;
$$;

-- Trigger: new comment
CREATE OR REPLACE FUNCTION public.notify_on_annotation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  PERFORM public.notify_proof_recipients(
    NEW.proof_id,
    NEW.author_id,
    'comment',
    COALESCE(NEW.author_name, 'Someone') || ' left a comment: "' ||
      CASE WHEN length(NEW.body) > 80 THEN substring(NEW.body, 1, 80) || '…' ELSE NEW.body END || '"',
    NEW.author_name
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_notify_on_annotation
AFTER INSERT ON public.annotations
FOR EACH ROW EXECUTE FUNCTION public.notify_on_annotation();

-- Trigger: file status change
CREATE OR REPLACE FUNCTION public.notify_on_file_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_msg text;
  v_type text;
BEGIN
  IF NEW.status IS NULL OR NEW.status = OLD.status THEN
    RETURN NEW;
  END IF;
  IF NEW.status NOT IN ('approved','changes_requested') THEN
    RETURN NEW;
  END IF;

  IF NEW.status = 'approved' THEN
    v_type := 'approved';
    v_msg := COALESCE(NEW.status_changed_by, 'Someone') || ' approved a file';
  ELSE
    v_type := 'changes_requested';
    v_msg := COALESCE(NEW.status_changed_by, 'Someone') || ' requested changes on a file';
  END IF;

  PERFORM public.notify_proof_recipients(
    NEW.proof_id,
    NULL,
    v_type,
    v_msg,
    NEW.status_changed_by
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_notify_on_file_status
AFTER UPDATE OF status ON public.proof_files
FOR EACH ROW EXECUTE FUNCTION public.notify_on_file_status();
