
CREATE POLICY "View profiles of users sharing a proof"
ON public.profiles
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.proofs p
    WHERE p.owner_id = profiles.id
      AND (p.owner_id = auth.uid() OR public.is_proof_collaborator(p.id, auth.uid()))
  )
  OR EXISTS (
    SELECT 1
    FROM public.proof_collaborators pc
    JOIN public.proofs p ON p.id = pc.proof_id
    WHERE pc.user_id = profiles.id
      AND (p.owner_id = auth.uid() OR public.is_proof_collaborator(p.id, auth.uid()))
  )
);
