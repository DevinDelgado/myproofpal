
-- Fix set_updated_at search path
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Restrict execute on handle_new_user (called only by trigger)
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

-- Tighten storage listing: replace broad SELECT with one that only allows reading individual objects, not listing
DROP POLICY IF EXISTS "Public read access for proofs" ON storage.objects;

-- Public buckets are still accessible directly via URL without this policy.
-- We add a policy only for owners to list their own files.
CREATE POLICY "Users can list their own proof files"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'proofs' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Tighten annotations insert: require valid proof_id (not always true)
DROP POLICY IF EXISTS "Anyone can insert annotations" ON public.annotations;

CREATE POLICY "Anyone can insert annotations on existing proofs"
  ON public.annotations FOR INSERT
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.proofs p WHERE p.id = proof_id)
    AND length(body) > 0
    AND length(author_name) > 0
  );
