
DROP POLICY IF EXISTS "Anyone can view proofs (for share links)" ON public.proofs;
DROP POLICY IF EXISTS "Anyone can view annotations" ON public.annotations;

CREATE POLICY "Owners can view annotations on their proofs"
ON public.annotations
FOR SELECT
USING (EXISTS (
  SELECT 1 FROM public.proofs p
  WHERE p.id = annotations.proof_id AND p.owner_id = auth.uid()
));
