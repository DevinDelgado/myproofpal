
-- ============================================================
-- 1. UNDO collaborator feature
-- ============================================================

-- Drop policies that reference is_proof_collaborator
DROP POLICY IF EXISTS "Collaborators can view proofs" ON public.proofs;
DROP POLICY IF EXISTS "Collaborators can update proofs" ON public.proofs;
DROP POLICY IF EXISTS "Collaborators can view files" ON public.proof_files;
DROP POLICY IF EXISTS "Collaborators can insert files" ON public.proof_files;
DROP POLICY IF EXISTS "Collaborators can update files" ON public.proof_files;
DROP POLICY IF EXISTS "Collaborators can delete files" ON public.proof_files;
DROP POLICY IF EXISTS "Collaborators can view annotations" ON public.annotations;
DROP POLICY IF EXISTS "Collaborators can insert annotations" ON public.annotations;
DROP POLICY IF EXISTS "Collaborators can update annotations" ON public.annotations;
DROP POLICY IF EXISTS "Collaborators can view events" ON public.proof_events;
DROP POLICY IF EXISTS "Collaborators can insert events" ON public.proof_events;
DROP POLICY IF EXISTS "View profiles of users sharing a proof" ON public.profiles;

DROP POLICY IF EXISTS "Owner or self can view collaborators" ON public.proof_collaborators;
DROP POLICY IF EXISTS "Owner can add collaborators" ON public.proof_collaborators;
DROP POLICY IF EXISTS "Owner can remove collaborators" ON public.proof_collaborators;

DROP TABLE IF EXISTS public.proof_collaborators;
DROP FUNCTION IF EXISTS public.is_proof_collaborator(uuid, uuid);

-- ============================================================
-- 2. TEAMS
-- ============================================================
CREATE TABLE public.teams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  owner_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.teams TO authenticated;
GRANT ALL ON public.teams TO service_role;
ALTER TABLE public.teams ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.team_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id uuid NOT NULL REFERENCES public.teams(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  role text NOT NULL DEFAULT 'member',
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (team_id, user_id)
);
GRANT SELECT, INSERT, DELETE ON public.team_members TO authenticated;
GRANT ALL ON public.team_members TO service_role;
ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;

-- Helper: is user a member of team
CREATE OR REPLACE FUNCTION public.is_team_member(_team_id uuid, _user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.team_members WHERE team_id = _team_id AND user_id = _user_id);
$$;

-- Helper: do two users share at least one team
CREATE OR REPLACE FUNCTION public.users_share_team(_a uuid, _b uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.team_members ma
    JOIN public.team_members mb ON ma.team_id = mb.team_id
    WHERE ma.user_id = _a AND mb.user_id = _b
  );
$$;

REVOKE EXECUTE ON FUNCTION public.is_team_member(uuid,uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_team_member(uuid,uuid) TO authenticated, service_role;
REVOKE EXECUTE ON FUNCTION public.users_share_team(uuid,uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.users_share_team(uuid,uuid) TO authenticated, service_role;

-- Teams policies
CREATE POLICY "Members can view their teams" ON public.teams FOR SELECT
  USING (public.is_team_member(id, auth.uid()) OR owner_id = auth.uid());
CREATE POLICY "Authenticated can create teams" ON public.teams FOR INSERT
  WITH CHECK (owner_id = auth.uid());
CREATE POLICY "Owner can update team" ON public.teams FOR UPDATE
  USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "Owner can delete team" ON public.teams FOR DELETE
  USING (owner_id = auth.uid());

-- Team members policies
CREATE POLICY "Members can view team_members of their teams" ON public.team_members FOR SELECT
  USING (
    user_id = auth.uid()
    OR public.is_team_member(team_id, auth.uid())
    OR EXISTS (SELECT 1 FROM public.teams t WHERE t.id = team_id AND t.owner_id = auth.uid())
  );
CREATE POLICY "Team owner can add members" ON public.team_members FOR INSERT
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.teams t WHERE t.id = team_id AND t.owner_id = auth.uid())
  );
CREATE POLICY "Team owner can remove members; self can leave" ON public.team_members FOR DELETE
  USING (
    user_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.teams t WHERE t.id = team_id AND t.owner_id = auth.uid())
  );

-- Trigger: when a team is created, add owner as a member with role 'owner'
CREATE OR REPLACE FUNCTION public.handle_new_team()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.team_members (team_id, user_id, role)
  VALUES (NEW.id, NEW.owner_id, 'owner')
  ON CONFLICT (team_id, user_id) DO NOTHING;
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_handle_new_team
AFTER INSERT ON public.teams
FOR EACH ROW EXECUTE FUNCTION public.handle_new_team();

-- ============================================================
-- 3. PROOF ASSIGNEES (additional users assigned to a proof)
-- ============================================================
CREATE TABLE public.proof_assignees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  proof_id uuid NOT NULL REFERENCES public.proofs(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  assigned_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (proof_id, user_id)
);
GRANT SELECT, INSERT, DELETE ON public.proof_assignees TO authenticated;
GRANT ALL ON public.proof_assignees TO service_role;
ALTER TABLE public.proof_assignees ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_proof_assignee(_proof_id uuid, _user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.proof_assignees WHERE proof_id = _proof_id AND user_id = _user_id);
$$;
REVOKE EXECUTE ON FUNCTION public.is_proof_assignee(uuid,uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_proof_assignee(uuid,uuid) TO authenticated, service_role;

-- Helper: can the user access this proof (owner, assignee, or team-mate of owner)
CREATE OR REPLACE FUNCTION public.can_access_proof(_proof_id uuid, _user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.proofs p
    WHERE p.id = _proof_id
      AND (
        p.owner_id = _user_id
        OR public.is_proof_assignee(p.id, _user_id)
        OR public.users_share_team(p.owner_id, _user_id)
      )
  );
$$;
REVOKE EXECUTE ON FUNCTION public.can_access_proof(uuid,uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_access_proof(uuid,uuid) TO authenticated, service_role;

-- Helper: can the user edit this proof (owner or assignee)
CREATE OR REPLACE FUNCTION public.can_edit_proof(_proof_id uuid, _user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.proofs p
    WHERE p.id = _proof_id
      AND (p.owner_id = _user_id OR public.is_proof_assignee(p.id, _user_id))
  );
$$;
REVOKE EXECUTE ON FUNCTION public.can_edit_proof(uuid,uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_edit_proof(uuid,uuid) TO authenticated, service_role;

-- proof_assignees policies
CREATE POLICY "View assignees if can access proof" ON public.proof_assignees FOR SELECT
  USING (user_id = auth.uid() OR public.can_access_proof(proof_id, auth.uid()));
CREATE POLICY "Owner can add assignees" ON public.proof_assignees FOR INSERT
  WITH CHECK (EXISTS (SELECT 1 FROM public.proofs p WHERE p.id = proof_id AND p.owner_id = auth.uid()));
CREATE POLICY "Owner can remove assignees; self can remove" ON public.proof_assignees FOR DELETE
  USING (
    user_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.proofs p WHERE p.id = proof_id AND p.owner_id = auth.uid())
  );

-- ============================================================
-- 4. Extend proofs / files / annotations / events access
-- ============================================================
CREATE POLICY "Team or assignee can view proofs" ON public.proofs FOR SELECT
  USING (
    owner_id = auth.uid()
    OR public.is_proof_assignee(id, auth.uid())
    OR public.users_share_team(owner_id, auth.uid())
  );

CREATE POLICY "Assignees can update proofs" ON public.proofs FOR UPDATE
  USING (public.is_proof_assignee(id, auth.uid()))
  WITH CHECK (public.is_proof_assignee(id, auth.uid()));

-- proof_files
CREATE POLICY "Can view files if access" ON public.proof_files FOR SELECT
  USING (public.can_access_proof(proof_id, auth.uid()));
CREATE POLICY "Can write files if edit" ON public.proof_files FOR INSERT
  WITH CHECK (public.can_edit_proof(proof_id, auth.uid()));
CREATE POLICY "Can update files if edit" ON public.proof_files FOR UPDATE
  USING (public.can_edit_proof(proof_id, auth.uid()))
  WITH CHECK (public.can_edit_proof(proof_id, auth.uid()));
CREATE POLICY "Can delete files if edit" ON public.proof_files FOR DELETE
  USING (public.can_edit_proof(proof_id, auth.uid()));

-- annotations
CREATE POLICY "Can view annotations if access" ON public.annotations FOR SELECT
  USING (public.can_access_proof(proof_id, auth.uid()));
CREATE POLICY "Can insert annotations if access" ON public.annotations FOR INSERT
  WITH CHECK (
    public.can_access_proof(proof_id, auth.uid())
    AND length(body) > 0 AND length(author_name) > 0
  );
CREATE POLICY "Can update own annotations if edit" ON public.annotations FOR UPDATE
  USING (public.can_edit_proof(proof_id, auth.uid()));

-- proof_events
CREATE POLICY "Can view events if access" ON public.proof_events FOR SELECT
  USING (public.can_access_proof(proof_id, auth.uid()));
CREATE POLICY "Can insert events if access" ON public.proof_events FOR INSERT
  WITH CHECK (public.can_access_proof(proof_id, auth.uid()));

-- profiles: allow seeing profiles of users sharing a team or a proof with you
CREATE POLICY "View profiles of teammates and proof collaborators" ON public.profiles FOR SELECT
TO authenticated
USING (
  id = auth.uid()
  OR public.users_share_team(id, auth.uid())
  OR EXISTS (
    SELECT 1 FROM public.proofs p
    WHERE (p.owner_id = id OR public.is_proof_assignee(p.id, id))
      AND (p.owner_id = auth.uid() OR public.is_proof_assignee(p.id, auth.uid()))
  )
);
