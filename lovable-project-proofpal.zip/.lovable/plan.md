## Goal

Allow each proof (job) to contain multiple image files. Reviewers can browse between files, comment on each one, and approve/request changes at the proof level.

## Database

Add a new `proof_files` table:
- `id`, `proof_id` (FK to proofs), `image_url`, `image_path`, `position` (int), `created_at`
- RLS:
  - Owners can manage files on their own proofs
  - Public read via the existing `get-shared-proof` edge function (service role)

Add `file_id` (nullable uuid) to `annotations` so comments are attached to a specific file. Existing annotations stay backward-compatible (null = legacy).

Migrate existing data: for every current proof, insert one row into `proof_files` using its `image_url`/`image_path` (position 0). Backfill existing annotations' `file_id` to that file.

Keep `proofs.image_url`/`image_path` as a "cover" pointer (first file) so the dashboard cards keep working without extra joins.

## Upload form (Dashboard)

- File input becomes `multiple`.
- Show list of selected files with remove buttons.
- On submit: upload each file to storage, insert the proof, then insert one row per file into `proof_files`. Set the first file as the cover on the proof.

## Proof viewer (ProofView)

- Fetch `proof_files` for the proof (owner: direct query; share view: via updated `get-shared-proof` edge function returning the files array).
- Show a thumbnail strip (horizontal scroll) below the title, with the active file highlighted.
- Main image area renders the active file; clicking on it creates an annotation tied to `file_id = active`.
- Comment sidebar shows only annotations for the active file, plus a counter badge per thumbnail showing total comments.
- Replace button now replaces the **active** file (updates that `proof_files` row).
- Add a separate "Add file" button (owner only) to append a new file to the proof.
- Owner can delete an individual file (with a confirm dialog) as long as at least one file remains.
- Approve / Request changes stay at the proof level (unchanged).

## Edge function

Update `get-shared-proof` to also return `files: [{ id, image_url, position }]` and have `post-shared-annotation` accept an optional `file_id`.

## Out of scope

- Per-file approval state
- Reordering files via drag-and-drop (position is set on upload order, can revisit later)
- PDF / non-image files

## Technical notes

- Storage bucket `proofs` is reused; new files use the same `${user.id}/${uuid}.${ext}` path pattern.
- Realtime broadcast channel `proof-${id}` keeps file list and annotations in sync; add a new `file` event for add/replace/delete.
- TypeScript types for `proof_files` come from the auto-generated `types.ts` after the migration is applied.
