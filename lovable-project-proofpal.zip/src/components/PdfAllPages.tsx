import { useState } from "react";
import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/Page/AnnotationLayer.css";
import "react-pdf/dist/Page/TextLayer.css";
import { Loader2 } from "lucide-react";

// Use the bundled worker from pdfjs-dist via Vite's ?url import
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import pdfWorker from "pdfjs-dist/build/pdf.worker.min.mjs?url";

pdfjs.GlobalWorkerOptions.workerSrc = pdfWorker;

interface PdfAllPagesProps {
  url: string;
  className?: string;
}

export const PdfAllPages = ({ url, className }: PdfAllPagesProps) => {
  const [numPages, setNumPages] = useState<number | null>(null);
  const [containerWidth, setContainerWidth] = useState<number>(0);

  return (
    <div
      className={className}
      ref={(el) => {
        if (el && el.clientWidth !== containerWidth) {
          setContainerWidth(el.clientWidth);
        }
      }}
    >
      <Document
        file={url}
        onLoadSuccess={({ numPages }) => setNumPages(numPages)}
        loading={
          <div className="flex items-center justify-center py-12 text-muted-foreground">
            <Loader2 className="w-5 h-5 animate-spin mr-2" /> Loading PDF…
          </div>
        }
        error={
          <div className="py-8 text-center text-sm text-destructive">
            Failed to load PDF.
          </div>
        }
      >
        {Array.from({ length: numPages ?? 0 }, (_, i) => (
          <div
            key={`page_${i + 1}`}
            className="mb-3 last:mb-0 rounded-md overflow-hidden shadow-soft bg-background"
          >
            <Page
              pageNumber={i + 1}
              width={containerWidth || undefined}
              renderAnnotationLayer={false}
              renderTextLayer={false}
            />
            <div className="text-[11px] text-muted-foreground text-center py-1">
              Page {i + 1} of {numPages}
            </div>
          </div>
        ))}
      </Document>
    </div>
  );
};
