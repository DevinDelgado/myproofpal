import { cn } from "@/lib/utils";
import { CheckCircle2, Clock, AlertCircle } from "lucide-react";

type Status = "pending" | "approved" | "changes_requested";

const config: Record<Status, { label: string; className: string; Icon: typeof Clock }> = {
  pending: {
    label: "Pending review",
    className: "bg-muted text-muted-foreground border-border",
    Icon: Clock,
  },
  approved: {
    label: "Approved",
    className: "bg-success/10 text-success border-success/20",
    Icon: CheckCircle2,
  },
  changes_requested: {
    label: "Changes requested",
    className: "bg-warning/10 text-warning border-warning/20",
    Icon: AlertCircle,
  },
};

export const StatusBadge = ({ status, className }: { status: Status; className?: string }) => {
  const { label, className: variant, Icon } = config[status];
  return (
    <span className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border", variant, className)}>
      <Icon className="w-3 h-3" />
      {label}
    </span>
  );
};
