import { useEffect, useMemo, useRef, useState } from "react";
import { useParams, useSearchParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { StatusBadge } from "@/components/StatusBadge";
import { PdfAllPages } from "@/components/PdfAllPages";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  Loader2,
  Send,
  Share2,
  Check,
  AlertCircle,
  ArrowLeft,
  MessageCircle,
  Trash2,
  Upload,
  Plus,
  FileText,
  History,
  CheckCircle2,
  RefreshCw,
  FilePlus2,
  FileX2,
  Users,
  UserPlus,
  X,
  Mail,
  Link2,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format, formatDistanceToNow } from "date-fns";

const isPdfUrl = (url?: string | null) => !!url && /\.pdf($|\?)/i.test(url);

const describeEvent = (ev: { event_type: string; details: Record<string, any> | null }) => {
  const d = ev.details ?? {};
  switch (ev.event_type) {
    case "status_changed": {
      const to = d.to as string | undefined;
      if (to === "approved")
        return {
          text: "approved the proof",
          icon: <CheckCircle2 className="w-4 h-4 text-success" />,
          iconBg: "bg-success/10",
        };
      if (to === "changes_requested")
        return {
          text: "requested changes",
          icon: <AlertCircle className="w-4 h-4 text-warning" />,
          iconBg: "bg-warning/10",
        };
      return {
        text: `set status to ${to ?? "pending"}`,
        icon: <History className="w-4 h-4 text-muted-foreground" />,
        iconBg: "bg-muted",
      };
    }
    case "file_status_changed": {
      const to = d.to as string | undefined;
      const pos = d.position as number | undefined;
      const label = pos != null ? `file ${pos + 1}` : "a file";
      if (to === "approved")
        return {
          text: `approved ${label}`,
          icon: <CheckCircle2 className="w-4 h-4 text-success" />,
          iconBg: "bg-success/10",
        };
      if (to === "changes_requested")
        return {
          text: `requested changes on ${label}`,
          icon: <AlertCircle className="w-4 h-4 text-warning" />,
          iconBg: "bg-warning/10",
        };
      return {
        text: `updated ${label}`,
        icon: <History className="w-4 h-4 text-muted-foreground" />,
        iconBg: "bg-muted",
      };
    }
    case "file_added": {
      const n = (d.count as number) ?? 1;
      return {
        text: n > 1 ? `added ${n} files` : "added a file",
        icon: <FilePlus2 className="w-4 h-4 text-primary" />,
        iconBg: "bg-primary/10",
      };
    }
    case "file_replaced":
      return {
        text: "replaced a file",
        icon: <RefreshCw className="w-4 h-4 text-primary" />,
        iconBg: "bg-primary/10",
      };
    case "file_deleted":
      return {
        text: "deleted a file",
        icon: <FileX2 className="w-4 h-4 text-destructive" />,
        iconBg: "bg-destructive/10",
      };
    case "collaborator_added":
    case "assignee_added":
      return {
        text: d.email ? `assigned ${d.email}` : "assigned someone to this proof",
        icon: <UserPlus className="w-4 h-4 text-primary" />,
        iconBg: "bg-primary/10",
      };
    case "collaborator_removed":
    case "assignee_removed":
      return {
        text: d.email ? `unassigned ${d.email}` : "removed an assignee",
        icon: <X className="w-4 h-4 text-muted-foreground" />,
        iconBg: "bg-muted",
      };
    default:
      return {
        text: ev.event_type.replace(/_/g, " "),
        icon: <History className="w-4 h-4 text-muted-foreground" />,
        iconBg: "bg-muted",
      };
  }
};

type Proof = {
  id: string;
  owner_id: string;
  title: string;
  description: string | null;
  image_url: string;
  image_path: string;
  status: "pending" | "approved" | "changes_requested";
  status_changed_by: string | null;
  status_changed_at: string | null;
  share_token: string;
  created_at: string;
};

type ProofFile = {
  id: string;
  image_url: string;
  image_path: string;
  position: number;
  created_at?: string;
  status?: "pending" | "approved" | "changes_requested";
  status_changed_by?: string | null;
  status_changed_at?: string | null;
};

type Annotation = {
  id: string;
  proof_id: string;
  file_id: string | null;
  author_id: string | null;
  author_name: string;
  body: string;
  x: number | null;
  y: number | null;
  resolved: boolean;
  created_at: string;
};
type ProofEvent = {
  id: string;
  actor_name: string;
  event_type: string;
  details: Record<string, any> | null;
  created_at: string;
};

type Assignee = {
  user_id: string;
  email: string | null;
  display_name: string | null;
};

type TeamMate = {
  user_id: string;
  email: string | null;
  display_name: string | null;
};

const ProofView = () => {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const shareToken = searchParams.get("share");
  const { user } = useAuth();

  const [proof, setProof] = useState<Proof | null>(null);
  const [files, setFiles] = useState<ProofFile[]>([]);
  const [activeFileId, setActiveFileId] = useState<string | null>(null);
  const [annotations, setAnnotations] = useState<Annotation[]>([]);
  const [events, setEvents] = useState<ProofEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [pending, setPending] = useState<{ x: number; y: number } | null>(null);
  const [body, setBody] = useState("");
  const [name, setName] = useState("");
  const [posting, setPosting] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);
  const imgRef = useRef<HTMLDivElement>(null);
  const replaceInputRef = useRef<HTMLInputElement>(null);
  const addFileInputRef = useRef<HTMLInputElement>(null);
  const [replacing, setReplacing] = useState(false);
  const [adding, setAdding] = useState(false);
  const [approveOpen, setApproveOpen] = useState(false);
  const [approveChecks, setApproveChecks] = useState({ fonts: false, spelling: false, content: false });
  const allApproveChecked = approveChecks.fonts && approveChecks.spelling && approveChecks.content;
  const [assignees, setAssignees] = useState<Assignee[]>([]);
  const [assignOpen, setAssignOpen] = useState(false);
  const [teamMates, setTeamMates] = useState<TeamMate[]>([]);
  const [ownerProfile, setOwnerProfile] = useState<{ display_name: string | null; email: string | null } | null>(null);
  const [emailShareOpen, setEmailShareOpen] = useState(false);
  const [emailTo, setEmailTo] = useState("");
  const [emailSubject, setEmailSubject] = useState("");
  const [emailMessage, setEmailMessage] = useState("");

  const isOwner = !!user && !!proof && user.id === proof.owner_id;
  const isAssignee = !!user && assignees.some((a) => a.user_id === user.id);
  const canEdit = isOwner || isAssignee;
  const isShareView = !!shareToken;

  const activeFile = useMemo(
    () => files.find((f) => f.id === activeFileId) ?? files[0] ?? null,
    [files, activeFileId]
  );

  const fileAnnotations = useMemo(
    () => annotations.filter((a) => (activeFile ? a.file_id === activeFile.id : true)),
    [annotations, activeFile]
  );

  const annotationCountByFile = useMemo(() => {
    const map: Record<string, number> = {};
    annotations.forEach((a) => {
      if (a.file_id) map[a.file_id] = (map[a.file_id] ?? 0) + 1;
    });
    return map;
  }, [annotations]);

  useEffect(() => {
    if (user?.email && !name) setName(user.email.split("@")[0]);
  }, [user, name]);

  useEffect(() => {
    if (!id) return;
    fetchAll();

    const channel = supabase
      .channel(`proof-${id}`, { config: { broadcast: { self: false } } })
      .on("broadcast", { event: "annotation" }, () => {
        fetchAnnotations();
      })
      .on("broadcast", { event: "status" }, (msg) => {
        const p = msg.payload as any;
        const status = p?.status as Proof["status"] | undefined;
        if (status)
          setProof((prev) =>
            prev
              ? {
                  ...prev,
                  status,
                  status_changed_by: p?.status_changed_by ?? prev.status_changed_by,
                  status_changed_at: p?.status_changed_at ?? prev.status_changed_at,
                }
              : prev
          );
        fetchEvents();
      })
      .on("broadcast", { event: "files" }, () => {
        fetchAll();
      })
      .on("broadcast", { event: "event" }, () => {
        fetchEvents();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const broadcast = (event: "annotation" | "status" | "files" | "event", payload: any = {}) => {
    supabase.channel(`proof-${id}`).send({ type: "broadcast", event, payload });
  };

  const logEvent = async (event_type: string, details: Record<string, any> = {}) => {
    if (!proof || !user) return;
    const actorName =
      user.user_metadata?.display_name || user.email?.split("@")[0] || "Owner";
    await supabase.from("proof_events").insert({
      proof_id: proof.id,
      actor_id: user.id,
      actor_name: actorName,
      event_type,
      details,
    });
    fetchEvents();
    broadcast("event");
  };

  const fetchEvents = async () => {
    if (!id) return;
    if (shareToken) {
      try {
        const res = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/get-shared-proof`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
              Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
            },
            body: JSON.stringify({ proof_id: id, share_token: shareToken }),
          }
        );
        const data = await res.json();
        setEvents(((data?.events ?? []) as ProofEvent[]));
      } catch (e) {
        console.error("fetchEvents error", e);
      }
      return;
    }
    const { data } = await supabase
      .from("proof_events")
      .select("id, actor_name, event_type, details, created_at")
      .eq("proof_id", id)
      .order("created_at", { ascending: false });
    setEvents((data ?? []) as ProofEvent[]);
  };

  useEffect(() => {
    if (proof) document.title = `${proof.title} – Proofly`;
  }, [proof]);

  const fetchAll = async () => {
    setLoading(true);
    if (shareToken) {
      try {
        const res = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/get-shared-proof`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
              Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
            },
            body: JSON.stringify({ proof_id: id, share_token: shareToken }),
          }
        );
        const data = await res.json();
        if (!res.ok || !data?.proof) {
          console.error("get-shared-proof failed", res.status, data);
          setProof(null);
          setLoading(false);
          return;
        }
        setProof(data.proof as Proof);
        const remoteFiles = (data.files ?? []) as ProofFile[];
        setFiles(remoteFiles);
        setActiveFileId((prev) => prev ?? remoteFiles[0]?.id ?? null);
        setAnnotations((data.annotations ?? []) as Annotation[]);
        setEvents((data.events ?? []) as ProofEvent[]);
      } catch (e) {
        console.error("get-shared-proof error", e);
        setProof(null);
      }
      setLoading(false);
      return;
    }

    const { data: p, error } = await supabase
      .from("proofs")
      .select("*")
      .eq("id", id!)
      .maybeSingle();
    if (error || !p) {
      toast.error("Proof not found");
      setProof(null);
      setLoading(false);
      return;
    }
    if (!user) {
      setProof(null);
      setLoading(false);
      return;
    }
    setProof(p as Proof);

    const { data: f } = await supabase
      .from("proof_files")
      .select("id, image_url, image_path, position, created_at, status, status_changed_by, status_changed_at")
      .eq("proof_id", id!)
      .order("position", { ascending: true })
      .order("created_at", { ascending: true });
    const list = (f ?? []) as ProofFile[];
    setFiles(list);
    setActiveFileId((prev) => prev ?? list[0]?.id ?? null);
    await fetchAnnotations();
    await fetchEvents();
    await fetchAssignees();
    await fetchOwnerProfile(p.owner_id);
    await fetchTeamMates();
    setLoading(false);
  };

  const fetchAssignees = async () => {
    if (!id || shareToken) return;
    const { data: rows } = await supabase
      .from("proof_assignees")
      .select("user_id, created_at")
      .eq("proof_id", id);
    const list = (rows ?? []) as { user_id: string; created_at: string }[];
    if (list.length === 0) {
      setAssignees([]);
      return;
    }
    const { data: profs } = await supabase
      .from("profiles")
      .select("id, email, display_name")
      .in("id", list.map((r) => r.user_id));
    const byId = new Map((profs ?? []).map((p) => [p.id, p]));
    setAssignees(
      list.map((r) => {
        const pr = byId.get(r.user_id);
        return {
          user_id: r.user_id,
          email: pr?.email ?? null,
          display_name: pr?.display_name ?? null,
        };
      })
    );
  };

  const fetchOwnerProfile = async (ownerId: string) => {
    const { data } = await supabase
      .from("profiles")
      .select("display_name, email")
      .eq("id", ownerId)
      .maybeSingle();
    setOwnerProfile(data ?? null);
  };

  const fetchTeamMates = async () => {
    if (!user) return;
    // teams the user belongs to
    const { data: myTeams } = await supabase
      .from("team_members")
      .select("team_id")
      .eq("user_id", user.id);
    const teamIds = (myTeams ?? []).map((t) => t.team_id);
    if (teamIds.length === 0) {
      setTeamMates([]);
      return;
    }
    const { data: members } = await supabase
      .from("team_members")
      .select("user_id")
      .in("team_id", teamIds);
    const uniqueIds = Array.from(new Set((members ?? []).map((m) => m.user_id))).filter(
      (u) => u !== user.id
    );
    if (uniqueIds.length === 0) {
      setTeamMates([]);
      return;
    }
    const { data: profs } = await supabase
      .from("profiles")
      .select("id, email, display_name")
      .in("id", uniqueIds);
    setTeamMates(
      (profs ?? []).map((p) => ({
        user_id: p.id,
        email: p.email,
        display_name: p.display_name,
      }))
    );
  };

  const fetchAnnotations = async () => {
    if (shareToken) {
      try {
        const res = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/get-shared-proof`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
              Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
            },
            body: JSON.stringify({ proof_id: id, share_token: shareToken }),
          }
        );
        const data = await res.json();
        setAnnotations(((data?.annotations ?? []) as Annotation[]));
      } catch (e) {
        console.error("fetchAnnotations error", e);
      }
      return;
    }
    const { data } = await supabase
      .from("annotations")
      .select("*")
      .eq("proof_id", id!)
      .order("created_at", { ascending: true });
    setAnnotations((data ?? []) as Annotation[]);
  };

  const handleImageClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!imgRef.current) return;
    const rect = imgRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setPending({ x, y });
    setActiveId(null);
  };

  const submitComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!body.trim() || !proof) return;
    if (!user && !name.trim()) {
      toast.error("Please add your name");
      return;
    }
    setPosting(true);
    const authorName = user
      ? user.user_metadata?.display_name || user.email?.split("@")[0] || "User"
      : name;

    if (isShareView && !isOwner) {
      const { error } = await supabase.functions.invoke("post-shared-annotation", {
        body: {
          proof_id: proof.id,
          share_token: shareToken,
          author_name: authorName,
          body: body.trim(),
          x: pending?.x ?? null,
          y: pending?.y ?? null,
          file_id: activeFile?.id ?? null,
        },
      });
      setPosting(false);
      if (error) return toast.error(error.message);
      setBody("");
      setPending(null);
      await fetchAnnotations();
      broadcast("annotation");
      toast.success("Comment posted");
      return;
    }

    const { error } = await supabase.from("annotations").insert({
      proof_id: proof.id,
      file_id: activeFile?.id ?? null,
      author_id: user?.id ?? null,
      author_name: authorName,
      body: body.trim(),
      x: pending?.x ?? null,
      y: pending?.y ?? null,
    });
    setPosting(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setBody("");
    setPending(null);
    await fetchAnnotations();
    broadcast("annotation");
    toast.success("Comment posted");
  };

  const updateFileStatus = async (status: ProofFile["status"]) => {
    if (!proof || !activeFile || !status) return;
    const actorName = user
      ? user.user_metadata?.display_name || user.email?.split("@")[0] || "Owner"
      : name.trim() || "Reviewer";
    const changedAt = new Date().toISOString();
    const prevStatus = activeFile.status ?? "pending";
    const position = files.findIndex((f) => f.id === activeFile.id);

    if (canEdit) {
      const { error } = await supabase
        .from("proof_files")
        .update({ status, status_changed_by: actorName, status_changed_at: changedAt })
        .eq("id", activeFile.id);
      if (error) return toast.error(error.message);
      await supabase.from("proof_events").insert({
        proof_id: proof.id,
        actor_id: user?.id ?? null,
        actor_name: actorName,
        event_type: "file_status_changed",
        details: { file_id: activeFile.id, from: prevStatus, to: status, position, via: "owner" },
      });
    } else {
      const { error } = await supabase.functions.invoke("update-proof-status", {
        body: {
          proof_id: proof.id,
          share_token: shareToken,
          status,
          actor_name: actorName,
          file_id: activeFile.id,
        },
      });
      if (error) return toast.error(error.message);
    }

    // Optimistic update of file + recompute aggregate proof status locally
    const updatedFiles = files.map((f) =>
      f.id === activeFile.id ? { ...f, status, status_changed_by: actorName, status_changed_at: changedAt } : f
    );
    setFiles(updatedFiles);

    const anyChanges = updatedFiles.some((f) => (f.status ?? "pending") === "changes_requested");
    const allApproved = updatedFiles.length > 0 && updatedFiles.every((f) => (f.status ?? "pending") === "approved");
    const newProofStatus: Proof["status"] = anyChanges ? "changes_requested" : allApproved ? "approved" : "pending";
    setProof({ ...proof, status: newProofStatus, status_changed_by: actorName, status_changed_at: changedAt });

    broadcast("files");
    broadcast("status", { status: newProofStatus, status_changed_by: actorName, status_changed_at: changedAt });
    fetchEvents();
    toast.success(
      status === "approved"
        ? allApproved
          ? "All files approved — proof approved"
          : "File approved"
        : "Changes requested on this file"
    );
  };


  const getShareUrl = () =>
    proof ? `${window.location.origin}/proofs/${proof.id}?share=${proof.share_token}` : "";

  const copyShareLink = () => {
    if (!proof) return;
    navigator.clipboard.writeText(getShareUrl());
    toast.success("Share link copied to clipboard");
  };

  const openEmailShare = () => {
    if (!proof) return;
    const senderName =
      user?.user_metadata?.display_name || user?.email?.split("@")[0] || "the team";
    setEmailTo("");
    setEmailSubject(`Please review and approve: ${proof.title}`);
    setEmailMessage(
      `Hi,\n\n${senderName} has shared a proof with you for review and approval.\n\nPlease take a look at "${proof.title}" using the link below and let us know if it looks good or if any changes are needed.\n\n${getShareUrl()}\n\nThanks!`
    );
    setEmailShareOpen(true);
  };

  const sendShareEmail = () => {
    const recipients = emailTo
      .split(/[\s,;]+/)
      .map((s) => s.trim())
      .filter(Boolean);
    if (recipients.length === 0) {
      toast.error("Add at least one recipient email");
      return;
    }
    const mailto = `mailto:${encodeURIComponent(recipients.join(","))}?subject=${encodeURIComponent(
      emailSubject
    )}&body=${encodeURIComponent(emailMessage)}`;
    window.location.href = mailto;
    setEmailShareOpen(false);
  };


  const toggleAssignee = async (teamMate: TeamMate, checked: boolean) => {
    if (!proof || !user) return;
    if (checked) {
      const { error } = await supabase
        .from("proof_assignees")
        .insert({ proof_id: proof.id, user_id: teamMate.user_id, assigned_by: user.id });
      if (error) {
        toast.error(error.message);
        return;
      }
      await supabase.from("proof_events").insert({
        proof_id: proof.id,
        actor_id: user.id,
        actor_name: user.user_metadata?.display_name || user.email?.split("@")[0] || "Owner",
        event_type: "assignee_added",
        details: { email: teamMate.email, user_id: teamMate.user_id },
      });
    } else {
      const { error } = await supabase
        .from("proof_assignees")
        .delete()
        .eq("proof_id", proof.id)
        .eq("user_id", teamMate.user_id);
      if (error) {
        toast.error(error.message);
        return;
      }
      await supabase.from("proof_events").insert({
        proof_id: proof.id,
        actor_id: user.id,
        actor_name: user.user_metadata?.display_name || user.email?.split("@")[0] || "Owner",
        event_type: "assignee_removed",
        details: { email: teamMate.email, user_id: teamMate.user_id },
      });
    }
    await fetchAssignees();
    fetchEvents();
  };


  const deleteAnnotation = async (annId: string) => {
    const { error } = await supabase.from("annotations").delete().eq("id", annId);
    if (error) return toast.error(error.message);
    setAnnotations((prev) => prev.filter((a) => a.id !== annId));
    if (activeId === annId) setActiveId(null);
    broadcast("annotation");
  };

  // Replace the currently-active file
  const handleReplaceFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file || !proof || !user || !activeFile) return;
    setReplacing(true);
    try {
      const ext = file.name.split(".").pop();
      const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("proofs").upload(path, file);
      if (upErr) throw upErr;
      const { data: pub } = supabase.storage.from("proofs").getPublicUrl(path);
      const oldPath = activeFile.image_path;
      const { error: updErr } = await supabase
        .from("proof_files")
        .update({ image_url: pub.publicUrl, image_path: path })
        .eq("id", activeFile.id);
      if (updErr) throw updErr;

      // Keep cover image in sync if this is the first file
      if (activeFile.position === 0 || files[0]?.id === activeFile.id) {
        await supabase
          .from("proofs")
          .update({ image_url: pub.publicUrl, image_path: path })
          .eq("id", proof.id);
        setProof({ ...proof, image_url: pub.publicUrl, image_path: path });
      }

      if (oldPath) {
        await supabase.storage.from("proofs").remove([oldPath]).catch(() => {});
      }
      setFiles((prev) =>
        prev.map((f) =>
          f.id === activeFile.id ? { ...f, image_url: pub.publicUrl, image_path: path } : f
        )
      );
      broadcast("files");
      logEvent("file_replaced", { file_id: activeFile.id });
      toast.success("File replaced");
    } catch (err: any) {
      toast.error(err.message ?? "Replace failed");
    } finally {
      setReplacing(false);
    }
  };

  // Append one or more new files to the proof
  const handleAddFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    e.target.value = "";
    if (!list || list.length === 0 || !proof || !user) return;
    setAdding(true);
    try {
      // Backfill: if this proof has no proof_files rows yet (legacy),
      // insert the original cover image as position 0 so it remains visible.
      let currentFiles = files;
      if (currentFiles.length === 0 && proof.image_url && proof.image_path) {
        const { data: seeded, error: seedErr } = await supabase
          .from("proof_files")
          .insert({
            proof_id: proof.id,
            image_url: proof.image_url,
            image_path: proof.image_path,
            position: 0,
          })
          .select("id, image_url, image_path, position, created_at")
          .single();
        if (seedErr) throw seedErr;
        currentFiles = [seeded as ProofFile];
        setFiles(currentFiles);
      }

      const basePosition =
        currentFiles.reduce((max, f) => Math.max(max, f.position ?? 0), -1) + 1;
      const toInsert: { proof_id: string; image_url: string; image_path: string; position: number }[] = [];
      let pos = basePosition;
      for (const file of Array.from(list)) {
        const ext = file.name.split(".").pop();
        const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
        const { error: upErr } = await supabase.storage.from("proofs").upload(path, file);
        if (upErr) throw upErr;
        const { data: pub } = supabase.storage.from("proofs").getPublicUrl(path);
        toInsert.push({
          proof_id: proof.id,
          image_url: pub.publicUrl,
          image_path: path,
          position: pos++,
        });
      }
      const { data: inserted, error: insErr } = await supabase
        .from("proof_files")
        .insert(toInsert)
        .select("id, image_url, image_path, position, created_at");
      if (insErr) throw insErr;
      const newOnes = (inserted ?? []) as ProofFile[];
      setFiles((prev) => [...prev, ...newOnes]);
      if (newOnes.length > 0) setActiveFileId(newOnes[0].id);
      broadcast("files");
      logEvent("file_added", { count: newOnes.length });
      toast.success(newOnes.length > 1 ? `${newOnes.length} files added` : "File added");
    } catch (err: any) {
      toast.error(err.message ?? "Upload failed");
    } finally {
      setAdding(false);
    }
  };

  const deleteFile = async (fileId: string) => {
    if (!proof) return;
    if (files.length <= 1) {
      toast.error("A proof must have at least one file");
      return;
    }
    const target = files.find((f) => f.id === fileId);
    if (!target) return;
    const { error } = await supabase.from("proof_files").delete().eq("id", fileId);
    if (error) return toast.error(error.message);
    if (target.image_path) {
      await supabase.storage.from("proofs").remove([target.image_path]).catch(() => {});
    }
    const remaining = files.filter((f) => f.id !== fileId);
    setFiles(remaining);
    if (activeFileId === fileId) setActiveFileId(remaining[0]?.id ?? null);

    // If we removed the cover, promote the new first file
    if (target.image_path === proof.image_path && remaining[0]) {
      await supabase
        .from("proofs")
        .update({ image_url: remaining[0].image_url, image_path: remaining[0].image_path })
        .eq("id", proof.id);
      setProof({ ...proof, image_url: remaining[0].image_url, image_path: remaining[0].image_path });
    }
    broadcast("files");
    logEvent("file_deleted", { file_id: fileId });
    toast.success("File deleted");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!proof) {
    return (
      <div className="min-h-screen flex flex-col">
        <AppHeader hideAuth={isShareView} hideNav={isShareView} />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center max-w-sm px-4">
            <p className="text-muted-foreground mb-1">This proof isn't available.</p>
            <p className="text-xs text-muted-foreground">The link may be invalid or has been removed.</p>
          </div>
        </div>
      </div>
    );
  }

  const pinAnnotations = fileAnnotations.filter((a) => a.x != null && a.y != null);
  const activeImageUrl = activeFile?.image_url ?? proof.image_url;

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <AppHeader hideAuth={isShareView && !user} hideNav={isShareView} />
      <main className="container py-6">
        <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
          <div className="flex items-center gap-3 min-w-0">
            {!isShareView && user && (
              <Button variant="ghost" size="icon" asChild>
                <Link to="/dashboard"><ArrowLeft className="w-4 h-4" /></Link>
              </Button>
            )}
            <div className="min-w-0">
              <h1 className="text-2xl font-semibold tracking-tight truncate">{proof.title}</h1>
              <p className="text-xs text-muted-foreground line-clamp-1">
                Owned by {ownerProfile?.display_name || ownerProfile?.email || "—"}
                {assignees.length > 0 && (
                  <> · Assigned to {assignees.map((a) => a.display_name || a.email).filter(Boolean).join(", ")}</>
                )}
              </p>
              {proof.description && <p className="text-sm text-muted-foreground line-clamp-1">{proof.description}</p>}
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex flex-col items-start gap-0.5">
              <StatusBadge status={proof.status} />
              {proof.status !== "pending" && proof.status_changed_by && (
                <span className="text-[11px] text-muted-foreground">
                  {proof.status === "approved" ? "Approved" : "Changes requested"} by {proof.status_changed_by}
                  {proof.status_changed_at && ` · ${formatDistanceToNow(new Date(proof.status_changed_at), { addSuffix: true })}`}
                </span>
              )}
            </div>
            {canEdit && !isShareView && (
              <>
                <input
                  ref={replaceInputRef}
                  type="file"
                  accept="image/*,application/pdf"
                  className="hidden"
                  onChange={handleReplaceFile}
                />
                <input
                  ref={addFileInputRef}
                  type="file"
                  accept="image/*,application/pdf"
                  multiple
                  className="hidden"
                  onChange={handleAddFiles}
                />
                <Button variant="outline" size="sm" onClick={() => replaceInputRef.current?.click()} disabled={replacing || !activeFile}>
                  {replacing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                  Replace
                </Button>
                <Button variant="outline" size="sm" onClick={() => addFileInputRef.current?.click()} disabled={adding}>
                  {adding ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                  Add files
                </Button>
                {isOwner && (
                  <>
                    <Dialog open={assignOpen} onOpenChange={setAssignOpen}>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <Users className="w-4 h-4 mr-2" />
                          Assignees{assignees.length > 0 ? ` (${assignees.length})` : ""}
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Assign teammates to this proof</DialogTitle>
                          <DialogDescription>
                            Assigned teammates get edit access. All your teammates can see this proof regardless.
                          </DialogDescription>
                        </DialogHeader>

                        <div className="mt-2">
                          {teamMates.length === 0 ? (
                            <p className="text-sm text-muted-foreground italic">
                              You don't have any teammates yet. Create or join a team first.
                            </p>
                          ) : (
                            <ul className="space-y-1.5 max-h-72 overflow-y-auto">
                              {teamMates.map((m) => {
                                const checked = assignees.some((a) => a.user_id === m.user_id);
                                return (
                                  <li
                                    key={m.user_id}
                                    className="flex items-center gap-3 rounded-md border border-border px-3 py-2"
                                  >
                                    <Checkbox
                                      checked={checked}
                                      onCheckedChange={(v) => toggleAssignee(m, !!v)}
                                    />
                                    <div className="min-w-0 flex-1">
                                      <p className="text-sm font-medium truncate">
                                        {m.display_name || m.email || m.user_id}
                                      </p>
                                      {m.email && m.display_name && (
                                        <p className="text-xs text-muted-foreground truncate">{m.email}</p>
                                      )}
                                    </div>
                                  </li>
                                );
                              })}
                            </ul>
                          )}
                        </div>

                        <DialogFooter>
                          <Button variant="outline" onClick={() => setAssignOpen(false)}>
                            Done
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="outline" size="sm">
                          <Share2 className="w-4 h-4 mr-2" /> Share
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={copyShareLink}>
                          <Link2 className="w-4 h-4 mr-2" /> Copy link
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={openEmailShare}>
                          <Mail className="w-4 h-4 mr-2" /> Email link
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </>
                )}
              </>
            )}
            {(canEdit || isShareView) && activeFile && (() => {
              const fileStatus = activeFile.status ?? "pending";
              const fileNumber = files.findIndex((f) => f.id === activeFile.id) + 1;
              const total = files.length;
              return (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => updateFileStatus("changes_requested")}
                    disabled={fileStatus === "changes_requested"}
                    className="text-warning border-warning/30 hover:bg-warning/10 hover:text-warning"
                  >
                    <AlertCircle className="w-4 h-4 mr-2" />
                    {fileStatus === "changes_requested" ? "Changes requested" : `Request changes${total > 1 ? ` on file ${fileNumber}` : ""}`}
                  </Button>
                  <AlertDialog
                    open={approveOpen}
                    onOpenChange={(o) => {
                      setApproveOpen(o);
                      if (!o) setApproveChecks({ fonts: false, spelling: false, content: false });
                    }}
                  >
                    <AlertDialogTrigger asChild>
                      <Button
                        size="sm"
                        disabled={fileStatus === "approved"}
                        className="bg-success hover:bg-success/90 text-success-foreground"
                      >
                        <Check className="w-4 h-4 mr-2" />
                        {fileStatus === "approved" ? "Approved" : `Approve${total > 1 ? ` file ${fileNumber}` : ""}`}
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>
                          {total > 1 ? `Approve file ${fileNumber} of ${total}` : "Confirm approval checklist"}
                        </AlertDialogTitle>
                        <AlertDialogDescription>
                          {total > 1
                            ? "Confirm you have reviewed this file. The proof is only marked approved once every file is approved."
                            : "Please confirm you have reviewed the following before approving this proof."}
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <div className="space-y-3 py-2">
                        <label className="flex items-start gap-3 cursor-pointer">
                          <Checkbox
                            checked={approveChecks.fonts}
                            onCheckedChange={(v) => setApproveChecks((p) => ({ ...p, fonts: !!v }))}
                            className="mt-0.5"
                          />
                          <span className="text-sm">Confirm fonts, typography &amp; styles</span>
                        </label>
                        <label className="flex items-start gap-3 cursor-pointer">
                          <Checkbox
                            checked={approveChecks.spelling}
                            onCheckedChange={(v) => setApproveChecks((p) => ({ ...p, spelling: !!v }))}
                            className="mt-0.5"
                          />
                          <span className="text-sm">Confirm spelling, grammar &amp; text accuracy</span>
                        </label>
                        <label className="flex items-start gap-3 cursor-pointer">
                          <Checkbox
                            checked={approveChecks.content}
                            onCheckedChange={(v) => setApproveChecks((p) => ({ ...p, content: !!v }))}
                            className="mt-0.5"
                          />
                          <span className="text-sm">Confirm content &amp; positions of all graphic elements</span>
                        </label>
                      </div>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          disabled={!allApproveChecked}
                          onClick={(e) => {
                            if (!allApproveChecked) {
                              e.preventDefault();
                              return;
                            }
                            updateFileStatus("approved");
                            setApproveOpen(false);
                            setApproveChecks({ fonts: false, spelling: false, content: false });
                          }}
                          className="bg-success hover:bg-success/90 text-success-foreground"
                        >
                          <Check className="w-4 h-4 mr-2" />
                          {total > 1 ? "Approve file" : "Approve proof"}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </>
              );
            })()}
          </div>
        </div>

        {files.length > 1 && (
          <div className="mb-4">
            <div className="flex items-center gap-2 overflow-x-auto pb-2">
              {files.map((f, idx) => {
                const isActive = activeFile?.id === f.id;
                const count = annotationCountByFile[f.id] ?? 0;
                const fStatus = f.status ?? "pending";
                const ringClass =
                  fStatus === "approved"
                    ? "border-success"
                    : fStatus === "changes_requested"
                    ? "border-warning"
                    : isActive
                    ? "border-primary"
                    : "border-border hover:border-primary/40";
                return (
                  <div key={f.id} className="relative flex-shrink-0 group">
                    <button
                      onClick={() => {
                        setActiveFileId(f.id);
                        setPending(null);
                        setActiveId(null);
                      }}
                      className={`relative block w-24 h-16 rounded-md overflow-hidden border-2 transition-smooth ${ringClass} ${
                        isActive ? "shadow-elegant ring-2 ring-primary/30" : ""
                      }`}
                      aria-label={`File ${idx + 1} — ${fStatus.replace("_", " ")}`}
                    >
                      {isPdfUrl(f.image_url) ? (
                        <div className="w-full h-full flex flex-col items-center justify-center bg-muted text-muted-foreground gap-0.5">
                          <FileText className="w-5 h-5" />
                          <span className="text-[9px] font-semibold">PDF</span>
                        </div>
                      ) : (
                        <img src={f.image_url} alt={`File ${idx + 1}`} className="w-full h-full object-cover" />
                      )}
                      <span className="absolute bottom-0.5 left-0.5 text-[10px] font-semibold px-1.5 py-0.5 rounded bg-background/80 backdrop-blur">
                        {idx + 1}
                      </span>
                      {fStatus === "approved" && (
                        <span className="absolute bottom-0.5 right-0.5 w-4 h-4 rounded-full bg-success text-success-foreground flex items-center justify-center">
                          <Check className="w-2.5 h-2.5" />
                        </span>
                      )}
                      {fStatus === "changes_requested" && (
                        <span className="absolute bottom-0.5 right-0.5 w-4 h-4 rounded-full bg-warning text-warning-foreground flex items-center justify-center">
                          <AlertCircle className="w-2.5 h-2.5" />
                        </span>
                      )}
                      {count > 0 && (
                        <span className="absolute top-0.5 right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-primary text-primary-foreground text-[10px] font-semibold flex items-center justify-center">
                          {count}
                        </span>
                      )}
                    </button>
                    {canEdit && !isShareView && files.length > 1 && (
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <button
                            className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-destructive text-destructive-foreground opacity-0 group-hover:opacity-100 transition-smooth flex items-center justify-center shadow-elegant"
                            aria-label="Delete file"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete this file?</AlertDialogTitle>
                            <AlertDialogDescription>
                              The file and all comments pinned to it will be removed. This cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => deleteFile(f.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    )}
                  </div>
                );
              })}
            </div>
            <p className="text-xs text-muted-foreground">
              File {files.findIndex((f) => f.id === activeFile?.id) + 1} of {files.length}
            </p>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-6">
          <Card className="p-4 shadow-soft">
            {isPdfUrl(activeImageUrl) ? (
              <>
                <div
                  className="relative bg-muted rounded-lg overflow-hidden max-h-[80vh] overflow-y-auto p-2"
                  onContextMenu={(e) => e.preventDefault()}
                >
                  <PdfAllPages url={activeImageUrl} />
                </div>
                <p className="text-xs text-muted-foreground mt-3 text-center">
                  💡 PDF preview — leave general comments below (pin comments are available on images)
                </p>
              </>
            ) : (
              <>
                <div
                  ref={imgRef}
                  onClick={handleImageClick}
                  onContextMenu={(e) => e.preventDefault()}
                  className="relative bg-muted rounded-lg overflow-hidden cursor-crosshair select-none"
                >
                  <img
                    src={activeImageUrl}
                    alt={proof.title}
                    className="w-full h-auto block pointer-events-none select-none"
                    draggable={false}
                    onDragStart={(e) => e.preventDefault()}
                  />
                  {!canEdit && (
                    <div className="absolute inset-0 pointer-events-none overflow-hidden" aria-hidden="true">
                      <div
                        className="absolute inset-[-50%] flex flex-wrap content-center justify-center gap-x-16 gap-y-12 opacity-20 -rotate-30"
                        style={{ transform: "rotate(-30deg)" }}
                      >
                        {Array.from({ length: 60 }).map((_, i) => (
                          <span key={i} className="text-foreground text-sm font-semibold tracking-widest uppercase whitespace-nowrap">
                            {proof.title} • For Review Only
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {pinAnnotations.map((a, i) => (
                    <button
                      key={a.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveId(activeId === a.id ? null : a.id);
                        setPending(null);
                      }}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 w-7 h-7 rounded-full text-xs font-semibold text-primary-foreground shadow-pin transition-smooth ${
                        a.resolved ? "bg-muted-foreground" : "bg-gradient-primary"
                      } ${activeId === a.id ? "ring-4 ring-primary/30 scale-110" : "hover:scale-110"}`}
                      style={{ left: `${a.x}%`, top: `${a.y}%` }}
                      aria-label={`Comment ${i + 1}`}
                    >
                      {i + 1}
                    </button>
                  ))}
                  {pending && (
                    <div
                      className="absolute -translate-x-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-primary/40 border-2 border-primary animate-pulse pointer-events-none"
                      style={{ left: `${pending.x}%`, top: `${pending.y}%` }}
                    />
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-3 text-center">
                  💡 Click anywhere on the image to drop a pin and add feedback
                </p>
              </>
            )}
          </Card>

          <div className="space-y-4">
            <Card className="p-4 shadow-soft">
              <Tabs defaultValue="comments" className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-4">
                  <TabsTrigger value="comments" className="gap-1.5">
                    <MessageCircle className="w-3.5 h-3.5" />
                    Comments ({fileAnnotations.length})
                  </TabsTrigger>
                  <TabsTrigger value="activity" className="gap-1.5">
                    <History className="w-3.5 h-3.5" />
                    Activity ({events.length})
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="comments" className="mt-0">
                  {files.length > 1 && (
                    <p className="text-xs text-muted-foreground mb-3">
                      Showing comments on file {files.findIndex((f) => f.id === activeFile?.id) + 1}
                    </p>
                  )}
                  <form onSubmit={submitComment} className="space-y-3 mb-5">
                    {!user && (
                      <Input placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} required />
                    )}
                    {pending && (
                      <div className="text-xs flex items-center gap-2 text-primary bg-accent rounded-md px-2 py-1.5">
                        <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                        Pinned to image
                        <button type="button" onClick={() => setPending(null)} className="ml-auto text-muted-foreground hover:text-foreground">
                          Cancel
                        </button>
                      </div>
                    )}
                    <Textarea
                      value={body}
                      onChange={(e) => setBody(e.target.value)}
                      placeholder={pending ? "Describe the change here..." : "Leave a general comment..."}
                      rows={3}
                      required
                    />
                    <Button type="submit" size="sm" className="w-full" disabled={posting || !body.trim()}>
                      {posting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
                      Post comment
                    </Button>
                  </form>

                  <div className="space-y-3 max-h-[500px] overflow-y-auto -mx-1 px-1">
                    {fileAnnotations.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-6">No comments yet on this file.</p>
                    )}
                    {fileAnnotations.map((a) => {
                      const pinIndex = a.x != null ? pinAnnotations.findIndex((p) => p.id === a.id) + 1 : null;
                      return (
                        <div
                          key={a.id}
                          onClick={() => a.x != null && setActiveId(a.id)}
                          className={`p-3 rounded-lg border transition-smooth ${
                            activeId === a.id ? "border-primary bg-accent" : "border-border bg-card hover:bg-accent/30"
                          } ${a.x != null ? "cursor-pointer" : ""}`}
                        >
                          <div className="flex items-start gap-2 mb-1.5">
                            {pinIndex && (
                              <span className="flex-shrink-0 w-5 h-5 rounded-full bg-gradient-primary text-primary-foreground text-[10px] font-semibold flex items-center justify-center">
                                {pinIndex}
                              </span>
                            )}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between gap-2">
                                <span className="text-sm font-medium truncate">{a.author_name}</span>
                                <span className="text-xs text-muted-foreground flex-shrink-0">
                                  {formatDistanceToNow(new Date(a.created_at), { addSuffix: true })}
                                </span>
                              </div>
                            </div>
                            {(canEdit || (user && user.id === a.author_id)) && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  deleteAnnotation(a.id);
                                }}
                                className="text-muted-foreground hover:text-destructive"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                          <p className="text-sm text-foreground/90 whitespace-pre-wrap break-words">{a.body}</p>
                        </div>
                      );
                    })}
                  </div>
                </TabsContent>

                <TabsContent value="activity" className="mt-0">
                  <div className="space-y-2 max-h-[600px] overflow-y-auto -mx-1 px-1">
                    {events.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-6">No activity yet.</p>
                    )}
                    {events.map((ev) => {
                      const meta = describeEvent(ev);
                      return (
                        <div
                          key={ev.id}
                          className="flex items-start gap-3 p-2.5 rounded-md border border-border bg-card"
                        >
                          <span className={`flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center ${meta.iconBg}`}>
                            {meta.icon}
                          </span>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-foreground">
                              <span className="font-medium">{ev.actor_name}</span>{" "}
                              <span className="text-muted-foreground">{meta.text}</span>
                            </p>
                            <p className="text-[11px] text-muted-foreground mt-0.5">
                              {format(new Date(ev.created_at), "MMM d, yyyy 'at' h:mm a")} ·{" "}
                              {formatDistanceToNow(new Date(ev.created_at), { addSuffix: true })}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </TabsContent>
              </Tabs>
            </Card>
          </div>
        </div>
      </main>

      <Dialog open={emailShareOpen} onOpenChange={setEmailShareOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Email share link</DialogTitle>
            <DialogDescription>
              Send the proof link directly to reviewers with a request for approval.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="email-to">To</Label>
              <Input
                id="email-to"
                type="text"
                placeholder="reviewer@example.com, another@example.com"
                value={emailTo}
                onChange={(e) => setEmailTo(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="email-subject">Subject</Label>
              <Input
                id="email-subject"
                value={emailSubject}
                onChange={(e) => setEmailSubject(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="email-message">Message</Label>
              <Textarea
                id="email-message"
                rows={8}
                value={emailMessage}
                onChange={(e) => setEmailMessage(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEmailShareOpen(false)}>
              Cancel
            </Button>
            <Button onClick={sendShareEmail}>
              <Mail className="w-4 h-4 mr-2" /> Open in email
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProofView;
