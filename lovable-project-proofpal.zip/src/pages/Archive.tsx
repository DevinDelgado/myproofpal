import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/StatusBadge";
import { toast } from "sonner";
import { ArrowLeft, ArchiveRestore, Loader2, FileText, Trash2 } from "lucide-react";
import { format } from "date-fns";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const isPdfUrl = (url?: string | null) => !!url && /\.pdf($|\?)/i.test(url);

type Proof = {
  id: string;
  title: string;
  image_url: string;
  image_path: string;
  status: "pending" | "approved" | "changes_requested";
  created_at: string;
  archived_at: string | null;
};

const Archive = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [proofs, setProofs] = useState<Proof[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !user) navigate("/auth");
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!user) return;
    document.title = "Archive – Proofly";
    fetchProofs();
  }, [user]);

  const fetchProofs = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("proofs")
      .select("id, title, image_url, image_path, status, created_at, archived_at")
      .not("archived_at", "is", null)
      .order("archived_at", { ascending: false });
    if (error) toast.error(error.message);
    else setProofs((data ?? []) as Proof[]);
    setLoading(false);
  };

  const handleRestore = async (proof: Proof) => {
    const { error } = await supabase
      .from("proofs")
      .update({ archived_at: null })
      .eq("id", proof.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    setProofs((prev) => prev.filter((p) => p.id !== proof.id));
    toast.success("Proof restored");
  };

  const handleDelete = async (proof: Proof) => {
    await supabase.storage.from("proofs").remove([proof.image_path]);
    const { error } = await supabase.from("proofs").delete().eq("id", proof.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    setProofs((prev) => prev.filter((p) => p.id !== proof.id));
    toast.success("Proof deleted");
  };

  if (authLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <AppHeader />
      <main className="container py-10">
        <div className="mb-8">
          <Button variant="ghost" size="sm" asChild className="mb-3 -ml-3">
            <Link to="/dashboard">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to dashboard
            </Link>
          </Button>
          <h1 className="text-3xl font-semibold tracking-tight">Archived proofs</h1>
          <p className="text-muted-foreground mt-1">Restore them to your dashboard or delete them permanently.</p>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : proofs.length === 0 ? (
          <Card className="p-16 text-center border-dashed">
            <p className="text-muted-foreground">No archived proofs.</p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {proofs.map((p) => (
              <Card key={p.id} className="overflow-hidden group hover:shadow-elegant transition-smooth border-border/60 h-full relative">
                <Link to={`/proofs/${p.id}`} className="block">
                  <div className="aspect-video bg-muted overflow-hidden flex items-center justify-center">
                    {isPdfUrl(p.image_url) ? (
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <FileText className="w-10 h-10" />
                        <span className="text-xs font-medium">PDF document</span>
                      </div>
                    ) : (
                      <img src={p.image_url} alt={p.title} className="w-full h-full object-cover" loading="lazy" />
                    )}
                  </div>
                  <div className="p-4">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <h3 className="font-medium tracking-tight line-clamp-1">{p.title}</h3>
                      <StatusBadge status={p.status} />
                    </div>
                    {p.archived_at && (
                      <p className="text-xs text-muted-foreground">
                        Archived {format(new Date(p.archived_at), "MMM d, yyyy 'at' h:mm a")}
                      </p>
                    )}
                  </div>
                </Link>
                <div className="absolute top-2 right-2 z-20 flex gap-2 opacity-0 group-hover:opacity-100 transition-smooth">
                  <Button
                    variant="secondary"
                    size="icon"
                    className="h-8 w-8 shadow-elegant"
                    aria-label="Restore proof"
                    onClick={() => handleRestore(p)}
                  >
                    <ArchiveRestore className="w-4 h-4" />
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="secondary" size="icon" className="h-8 w-8 shadow-elegant" aria-label="Delete proof">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete this proof?</AlertDialogTitle>
                        <AlertDialogDescription>
                          "{p.title}" and all its comments will be permanently removed. This cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleDelete(p)}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Archive;
