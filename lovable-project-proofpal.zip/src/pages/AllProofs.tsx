import { useEffect, useMemo, useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppHeader } from "@/components/AppHeader";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/StatusBadge";
import { ArrowLeft, Loader2, LayoutGrid, Grid2X2, List } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

type StatusFilter = "all" | "approved" | "pending" | "changes_requested";
type SortKey = "status" | "alphabetical";
type ViewMode = "grid" | "compact" | "list";

type Proof = {
  id: string;
  title: string;
  image_url: string;
  status: "pending" | "approved" | "changes_requested";
  created_at: string;
  status_changed_at: string | null;
  status_changed_by: string | null;
  owner_id: string;
};

type Profile = { id: string; display_name: string | null; email: string | null };

const AllProofs = () => {
  const { user, loading: authLoading } = useAuth();
  const [proofs, setProofs] = useState<Proof[]>([]);
  const [profiles, setProfiles] = useState<Record<string, Profile>>({});
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [sortKey, setSortKey] = useState<SortKey>("status");
  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    try {
      const saved = localStorage.getItem("allProofsViewMode");
      if (saved === "grid" || saved === "compact" || saved === "list") return saved;
    } catch {}
    return "grid";
  });

  useEffect(() => {
    try {
      localStorage.setItem("allProofsViewMode", viewMode);
    } catch {}
  }, [viewMode]);

  useEffect(() => {
    document.title = "Your proofs – Proofly";
    if (authLoading) return;
    if (!user) {
      setLoading(false);
      return;
    }
    (async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from("proofs")
        .select("id, title, image_url, status, created_at, status_changed_at, status_changed_by, owner_id")
        .order("created_at", { ascending: false });
      if (error) {
        toast.error(error.message);
        setLoading(false);
        return;
      }
      const list = data ?? [];
      setProofs(list);

      const ownerIds = Array.from(new Set(list.map((p) => p.owner_id)));
      if (ownerIds.length > 0) {
        const { data: profs } = await supabase
          .from("profiles")
          .select("id, display_name, email")
          .in("id", ownerIds);
        const map: Record<string, Profile> = {};
        (profs ?? []).forEach((pr) => (map[pr.id] = pr));
        setProfiles(map);
      }
      setLoading(false);
    })();
  }, [user, authLoading]);

  if (!authLoading && !user) {
    return <Navigate to="/auth" replace />;
  }


  const statusOrder: Record<Proof["status"], number> = {
    approved: 0,
    pending: 1,
    changes_requested: 2,
  };

  const visibleProofs = useMemo(() => {
    let list = proofs;
    if (statusFilter !== "all") {
      list = list.filter((p) => p.status === statusFilter);
    }
    const sorted = [...list];
    if (sortKey === "alphabetical") {
      sorted.sort((a, b) => a.title.localeCompare(b.title));
    } else {
      sorted.sort((a, b) => {
        const diff = statusOrder[a.status] - statusOrder[b.status];
        if (diff !== 0) return diff;
        return a.title.localeCompare(b.title);
      });
    }
    return sorted;
  }, [proofs, statusFilter, sortKey]);

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <AppHeader />
      <main className="container py-10">
        <div className="mb-8">
          <Button variant="ghost" size="sm" asChild className="mb-3 -ml-3">
            <Link to="/dashboard">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to dashboard
            </Link>
          </Button>
          <h1 className="text-3xl font-semibold tracking-tight">Your proofs</h1>
          <p className="text-muted-foreground mt-1">All proofs you've created on Proofly.</p>
        </div>

        {!loading && proofs.length > 0 && (
          <div className="flex flex-wrap items-center gap-3 mb-6">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Filter</span>
              <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as StatusFilter)}>
                <SelectTrigger className="w-[180px] h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="pending">Pending review</SelectItem>
                  <SelectItem value="changes_requested">Changes requested</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Sort</span>
              <Select value={sortKey} onValueChange={(v) => setSortKey(v as SortKey)}>
                <SelectTrigger className="w-[220px] h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="status">Status (approved first)</SelectItem>
                  <SelectItem value="alphabetical">Alphabetical (A–Z)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2 ml-auto">
              <span className="text-sm text-muted-foreground">View</span>
              <ToggleGroup type="single" value={viewMode} onValueChange={(v) => v && setViewMode(v as ViewMode)}>
                <ToggleGroupItem value="grid" aria-label="Grid view">
                  <LayoutGrid className="w-4 h-4" />
                </ToggleGroupItem>
                <ToggleGroupItem value="compact" aria-label="Compact view">
                  <Grid2X2 className="w-4 h-4" />
                </ToggleGroupItem>
                <ToggleGroupItem value="list" aria-label="List view">
                  <List className="w-4 h-4" />
                </ToggleGroupItem>
              </ToggleGroup>
            </div>
          </div>
        )}

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : proofs.length === 0 ? (
          <Card className="p-16 text-center border-dashed">
            <p className="text-muted-foreground">No proofs have been uploaded yet.</p>
          </Card>
        ) : visibleProofs.length === 0 ? (
          <Card className="p-16 text-center border-dashed">
            <p className="text-muted-foreground">No proofs match this filter.</p>
          </Card>
        ) : (
          viewMode === "list" ? (
            <Card className="border-border/60 overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[80px]">Preview</TableHead>
                    <TableHead>Title</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>Last action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {visibleProofs.map((p) => {
                    const owner = profiles[p.owner_id];
                    const ownerLabel = owner?.display_name || owner?.email || "Unknown";
                    return (
                      <TableRow key={p.id} className="cursor-pointer" onClick={() => window.location.href = `/proofs/${p.id}`}>
                        <TableCell>
                          <img
                            src={p.image_url}
                            alt={p.title}
                            className="w-16 h-10 object-cover rounded"
                            loading="lazy"
                          />
                        </TableCell>
                        <TableCell className="font-medium">{p.title}</TableCell>
                        <TableCell><StatusBadge status={p.status} /></TableCell>
                        <TableCell className="text-muted-foreground text-sm">
                          {format(new Date(p.created_at), "MMM d, yyyy 'at' h:mm a")}
                        </TableCell>
                        <TableCell className="text-muted-foreground text-sm">
                          {p.status !== "pending" && p.status_changed_at ? (
                            <>
                              {p.status === "approved" ? "Approved" : "Changes requested"}
                              {p.status_changed_by ? ` by ${p.status_changed_by}` : ""} · {format(new Date(p.status_changed_at), "MMM d, yyyy 'at' h:mm a")}
                            </>
                          ) : (
                            <span className="text-muted-foreground/50">—</span>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </Card>
          ) : viewMode === "compact" ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
              {visibleProofs.map((p) => (
                <Link key={p.id} to={`/proofs/${p.id}`} className="block">
                  <Card className="overflow-hidden group hover:shadow-elegant transition-smooth border-border/60 h-full">
                    <div className="aspect-video bg-muted overflow-hidden">
                      <img
                        src={p.image_url}
                        alt={p.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-smooth"
                        loading="lazy"
                      />
                    </div>
                    <div className="p-2.5">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h3 className="text-sm font-medium tracking-tight line-clamp-1">{p.title}</h3>
                        <StatusBadge status={p.status} />
                      </div>
                      <p className="text-[11px] text-muted-foreground">
                        {format(new Date(p.created_at), "MMM d, yyyy")}
                      </p>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {visibleProofs.map((p) => {
                const owner = profiles[p.owner_id];
                const ownerLabel = owner?.display_name || owner?.email || "Unknown";
                return (
                  <Link key={p.id} to={`/proofs/${p.id}`} className="block">
                    <Card className="overflow-hidden group hover:shadow-elegant transition-smooth border-border/60 h-full">
                      <div className="aspect-video bg-muted overflow-hidden">
                        <img
                          src={p.image_url}
                          alt={p.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-smooth"
                          loading="lazy"
                        />
                      </div>
                      <div className="p-4">
                        <div className="flex items-start justify-between gap-3 mb-2">
                          <h3 className="font-medium tracking-tight line-clamp-1">{p.title}</h3>
                          <StatusBadge status={p.status} />
                        </div>
                        <p className="text-xs text-muted-foreground">
                          by {ownerLabel} · Created {format(new Date(p.created_at), "MMM d, yyyy 'at' h:mm a")}
                        </p>
                        {p.status !== "pending" && p.status_changed_at && (
                          <p className="text-xs text-muted-foreground mt-1">
                            {p.status === "approved" ? "Approved" : "Changes requested"}
                            {p.status_changed_by ? ` by ${p.status_changed_by}` : ""} · {format(new Date(p.status_changed_at), "MMM d, yyyy 'at' h:mm a")}
                          </p>
                        )}
                      </div>
                    </Card>
                  </Link>
                );
              })}
            </div>
          )
        )}
      </main>
    </div>
  );
};

export default AllProofs;
