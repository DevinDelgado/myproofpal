import { useEffect, useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppHeader } from "@/components/AppHeader";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ArrowLeft, Loader2, Plus, UserPlus, Users, Trash2, LogOut } from "lucide-react";
import { toast } from "sonner";

type Team = {
  id: string;
  name: string;
  owner_id: string;
  created_at: string;
};

type Member = {
  user_id: string;
  role: string;
  email: string | null;
  display_name: string | null;
};

const Teams = () => {
  const { user, loading: authLoading } = useAuth();
  const [teams, setTeams] = useState<Team[]>([]);
  const [members, setMembers] = useState<Record<string, Member[]>>({});
  const [loading, setLoading] = useState(true);
  const [newTeamName, setNewTeamName] = useState("");
  const [creating, setCreating] = useState(false);
  const [openTeamId, setOpenTeamId] = useState<string | null>(null);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviting, setInviting] = useState(false);

  useEffect(() => {
    document.title = "Teams – Proofly";
    if (!authLoading && user) fetchTeams();
  }, [user, authLoading]);

  const fetchTeams = async () => {
    if (!user) return;
    setLoading(true);
    const { data: myTeams } = await supabase
      .from("teams")
      .select("id, name, owner_id, created_at")
      .order("created_at", { ascending: false });
    const list = (myTeams ?? []) as Team[];
    setTeams(list);

    if (list.length > 0) {
      const { data: mems } = await supabase
        .from("team_members")
        .select("team_id, user_id, role")
        .in("team_id", list.map((t) => t.id));
      const userIds = Array.from(new Set((mems ?? []).map((m) => m.user_id)));
      const { data: profs } = userIds.length
        ? await supabase
            .from("profiles")
            .select("id, email, display_name")
            .in("id", userIds)
        : { data: [] as any[] };
      const byId = new Map((profs ?? []).map((p: any) => [p.id, p]));
      const map: Record<string, Member[]> = {};
      (mems ?? []).forEach((m: any) => {
        const pr = byId.get(m.user_id);
        const entry: Member = {
          user_id: m.user_id,
          role: m.role,
          email: pr?.email ?? null,
          display_name: pr?.display_name ?? null,
        };
        if (!map[m.team_id]) map[m.team_id] = [];
        map[m.team_id].push(entry);
      });
      setMembers(map);
    } else {
      setMembers({});
    }
    setLoading(false);
  };

  const createTeam = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newTeamName.trim()) return;
    setCreating(true);
    const { error } = await supabase
      .from("teams")
      .insert({ name: newTeamName.trim(), owner_id: user.id });
    setCreating(false);
    if (error) return toast.error(error.message);
    setNewTeamName("");
    toast.success("Team created");
    fetchTeams();
  };

  const inviteMember = async (teamId: string) => {
    if (!inviteEmail.trim()) return;
    setInviting(true);
    const { data, error } = await supabase.functions.invoke("invite-team-member", {
      body: { team_id: teamId, email: inviteEmail.trim() },
    });
    setInviting(false);
    if (error || (data && (data as any).error)) {
      toast.error(((data as any)?.error as string) || error?.message || "Could not invite");
      return;
    }
    setInviteEmail("");
    toast.success("Member added");
    fetchTeams();
  };

  const removeMember = async (teamId: string, memberUserId: string) => {
    const { error } = await supabase
      .from("team_members")
      .delete()
      .eq("team_id", teamId)
      .eq("user_id", memberUserId);
    if (error) return toast.error(error.message);
    fetchTeams();
  };

  const deleteTeam = async (teamId: string) => {
    if (!confirm("Delete this team? All members will lose access.")) return;
    const { error } = await supabase.from("teams").delete().eq("id", teamId);
    if (error) return toast.error(error.message);
    toast.success("Team deleted");
    fetchTeams();
  };

  if (!authLoading && !user) return <Navigate to="/auth" replace />;

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <AppHeader />
      <main className="container py-10 max-w-3xl">
        <div className="mb-8">
          <Button variant="ghost" size="sm" asChild className="mb-3 -ml-3">
            <Link to="/dashboard">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to dashboard
            </Link>
          </Button>
          <h1 className="text-3xl font-semibold tracking-tight">Teams</h1>
          <p className="text-muted-foreground mt-1">
            Create a team and invite members. Teammates can see each other's proofs.
          </p>
        </div>

        <Card className="p-5 mb-6">
          <form onSubmit={createTeam} className="flex gap-2">
            <Input
              placeholder="New team name"
              value={newTeamName}
              onChange={(e) => setNewTeamName(e.target.value)}
              disabled={creating}
              required
            />
            <Button type="submit" disabled={creating || !newTeamName.trim()}>
              {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Plus className="w-4 h-4 mr-1" /> Create team</>}
            </Button>
          </form>
        </Card>

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : teams.length === 0 ? (
          <Card className="p-12 text-center border-dashed">
            <Users className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">You aren't on any teams yet.</p>
          </Card>
        ) : (
          <ul className="space-y-3">
            {teams.map((t) => {
              const isOwner = t.owner_id === user?.id;
              const teamMembers = members[t.id] ?? [];
              return (
                <Card key={t.id} className="p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h2 className="text-lg font-semibold tracking-tight">{t.name}</h2>
                      <p className="text-xs text-muted-foreground">
                        {teamMembers.length} member{teamMembers.length === 1 ? "" : "s"}
                        {isOwner ? " · You own this team" : ""}
                      </p>
                    </div>
                    <div className="flex gap-2 flex-shrink-0">
                      <Dialog open={openTeamId === t.id} onOpenChange={(o) => { setOpenTeamId(o ? t.id : null); setInviteEmail(""); }}>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm">
                            <Users className="w-4 h-4 mr-1" /> Manage
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>{t.name}</DialogTitle>
                            <DialogDescription>
                              {isOwner ? "Add or remove members." : "View team members. Only the owner can manage."}
                            </DialogDescription>
                          </DialogHeader>

                          {isOwner && (
                            <div className="space-y-2">
                              <Label htmlFor={`invite-${t.id}`}>Invite by email</Label>
                              <div className="flex gap-2">
                                <Input
                                  id={`invite-${t.id}`}
                                  type="email"
                                  placeholder="person@example.com"
                                  value={inviteEmail}
                                  onChange={(e) => setInviteEmail(e.target.value)}
                                  disabled={inviting}
                                />
                                <Button onClick={() => inviteMember(t.id)} disabled={inviting || !inviteEmail.trim()}>
                                  {inviting ? <Loader2 className="w-4 h-4 animate-spin" /> : <><UserPlus className="w-4 h-4 mr-1" /> Invite</>}
                                </Button>
                              </div>
                            </div>
                          )}

                          <ul className="space-y-1.5 max-h-72 overflow-y-auto mt-2">
                            {teamMembers.map((m) => (
                              <li key={m.user_id} className="flex items-center justify-between gap-2 rounded-md border border-border px-3 py-2">
                                <div className="min-w-0">
                                  <p className="text-sm font-medium truncate">
                                    {m.display_name || m.email || m.user_id}
                                    {m.role === "owner" && <span className="ml-2 text-xs text-muted-foreground">(owner)</span>}
                                  </p>
                                  {m.email && m.display_name && (
                                    <p className="text-xs text-muted-foreground truncate">{m.email}</p>
                                  )}
                                </div>
                                {((isOwner && m.role !== "owner") || m.user_id === user?.id) && m.role !== "owner" && (
                                  <Button variant="ghost" size="sm" onClick={() => removeMember(t.id, m.user_id)}
                                    className="text-destructive hover:text-destructive hover:bg-destructive/10">
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                )}
                              </li>
                            ))}
                          </ul>

                          <DialogFooter className="flex-row justify-between sm:justify-between">
                            {!isOwner && (
                              <Button variant="outline" onClick={() => removeMember(t.id, user!.id)}
                                className="text-destructive">
                                <LogOut className="w-4 h-4 mr-1" /> Leave team
                              </Button>
                            )}
                            <div className="flex gap-2 ml-auto">
                              {isOwner && (
                                <Button variant="outline" className="text-destructive" onClick={() => deleteTeam(t.id)}>
                                  <Trash2 className="w-4 h-4 mr-1" /> Delete team
                                </Button>
                              )}
                              <Button variant="outline" onClick={() => setOpenTeamId(null)}>Done</Button>
                            </div>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                  {teamMembers.length > 0 && (
                    <p className="mt-3 text-xs text-muted-foreground line-clamp-1">
                      {teamMembers.map((m) => m.display_name || m.email).filter(Boolean).join(", ")}
                    </p>
                  )}
                </Card>
              );
            })}
          </ul>
        )}
      </main>
    </div>
  );
};

export default Teams;
