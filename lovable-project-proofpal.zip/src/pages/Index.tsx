import { Link, Navigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { AppHeader } from "@/components/AppHeader";
import { CheckCircle2, MessageCircle, Share2, Sparkles } from "lucide-react";

const Index = () => {
  const { user, loading } = useAuth();

  if (loading) return null;
  if (user) return <Navigate to="/dashboard" replace />;

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <AppHeader />
      <main>
        <section className="container py-24 text-center max-w-3xl">
          <div className="inline-flex items-center gap-2 text-xs font-medium px-3 py-1 rounded-full bg-accent text-accent-foreground mb-6">
            <Sparkles className="w-3 h-3" /> Visual feedback, simplified
          </div>
          <h1 className="text-5xl md:text-6xl font-semibold tracking-tight mb-6 leading-[1.05]">
            Get crystal-clear feedback on your{" "}
            <span className="bg-gradient-primary bg-clip-text text-transparent">designs</span>.
          </h1>
          <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto">
            Upload images, share a link, and let clients pin comments directly on your work. Approve in one click.
          </p>
          <div className="flex items-center justify-center gap-3">
            <Button size="lg" asChild className="shadow-elegant">
              <Link to="/auth">Start for free</Link>
            </Button>
          </div>
        </section>

        <section className="container pb-24 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl">
          {[
            { icon: MessageCircle, title: "Pin comments", desc: "Reviewers click anywhere on the image to leave precise, contextual feedback." },
            { icon: Share2, title: "Share with anyone", desc: "Generate a link — no account required for clients to review and comment." },
            { icon: CheckCircle2, title: "Approve or iterate", desc: "Track status across all your proofs: pending, changes requested, or approved." },
          ].map(({ icon: Icon, title, desc }) => (
            <div key={title} className="p-6 rounded-2xl bg-card border border-border/60 shadow-soft">
              <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center mb-4">
                <Icon className="w-5 h-5 text-accent-foreground" />
              </div>
              <h3 className="font-semibold mb-1">{title}</h3>
              <p className="text-sm text-muted-foreground">{desc}</p>
            </div>
          ))}
        </section>
      </main>
    </div>
  );
};

export default Index;
