import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppHeader } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { StatusBadge } from "@/components/StatusBadge";
import { toast } from "sonner";
import { Plus, Upload, Loader2, ImagePlus, Trash2, Search, FileText, Archive as ArchiveIcon, LayoutGrid, Grid2X2, List, Users, Filter } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const isPdfUrl = (url?: string | null) => !!url && /\.pdf($|\?)/i.test(url);
import { formatDistanceToNow, format } from "date-fns";

type Proof = {
  id: string;
  owner_id: string;
  title: string;
  description: string | null;
  image_url: string;
  image_path: string;
  status: "pending" | "approved" | "changes_requested";
  created_at: string;
  status_changed_at: string | null;
  status_changed_by: string | null;
};

type OwnerProfile = { id: string; display_name: string | null; email: string | null };

type StatusFilter = "all" | "approved" | "pending" | "changes_requested";
type SortKey = "status" | "alphabetical" | "newest" | "oldest";
type ViewMode = "grid" | "compact" | "list";

const statusOrder: Record<Proof["status"], number> = {
  approved: 0,
  pending: 1,
  changes_requested: 2,
};

const Dashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [proofs, setProofs] = useState<Proof[]>([]);
  const [ownerProfiles, setOwnerProfiles] = useState<Record<string, OwnerProfile>>({});
  const [ownerFilter, setOwnerFilter] = useState<string[]>([]); // empty = all
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [sortKey, setSortKey] = useState<SortKey>("status");
  const [search, setSearch] = useState("");
  const [viewMode, setViewMode] = useState<ViewMode>(() => {
    try {
      const saved = localStorage.getItem("dashboardViewMode");
      if (saved === "grid" || saved === "compact" || saved === "list") return saved;
    } catch {}
    return "grid";
  });

  useEffect(() => {
    try {
      localStorage.setItem("dashboardViewMode", viewMode);
    } catch {}
  }, [viewMode]);

  const visibleProofs = useMemo(() => {
    let list = proofs;
    if (statusFilter !== "all") list = list.filter((p) => p.status === statusFilter);
    if (ownerFilter.length > 0) list = list.filter((p) => ownerFilter.includes(p.owner_id));
    const q = search.trim().toLowerCase();
    if (q) {
      list = list.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          (p.description ?? "").toLowerCase().includes(q)
      );
    }
    const sorted = [...list];
    if (sortKey === "alphabetical") {
      sorted.sort((a, b) => a.title.localeCompare(b.title));
    } else if (sortKey === "newest") {
      sorted.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    } else if (sortKey === "oldest") {
      sorted.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
    } else {
      sorted.sort((a, b) => {
        const diff = statusOrder[a.status] - statusOrder[b.status];
        if (diff !== 0) return diff;
        return a.title.localeCompare(b.title);
      });
    }
    return sorted;
  }, [proofs, statusFilter, sortKey, search, ownerFilter]);

  const uniqueOwners = useMemo(() => {
    const ids = Array.from(new Set(proofs.map((p) => p.owner_id)));
    return ids.map((id) => ownerProfiles[id] ?? { id, display_name: null, email: null });
  }, [proofs, ownerProfiles]);

  useEffect(() => {
    if (!authLoading && !user) navigate("/auth");
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!user) return;
    document.title = "Dashboard – Proofly";
    fetchProofs();
  }, [user]);

  const fetchProofs = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("proofs")
      .select("id, owner_id, title, description, image_url, image_path, status, created_at, status_changed_at, status_changed_by")
      .is("archived_at", null)
      .order("created_at", { ascending: false });
    if (error) {
      toast.error(error.message);
      setLoading(false);
      return;
    }
    const list = (data ?? []) as Proof[];
    setProofs(list);
    const ownerIds = Array.from(new Set(list.map((p) => p.owner_id)));
    if (ownerIds.length) {
      const { data: profs } = await supabase
        .from("profiles")
        .select("id, display_name, email")
        .in("id", ownerIds);
      const map: Record<string, OwnerProfile> = {};
      (profs ?? []).forEach((p: any) => (map[p.id] = p));
      setOwnerProfiles(map);
    }
    setLoading(false);
  };

  const handleArchive = async (proof: Proof) => {
    const { error } = await supabase
      .from("proofs")
      .update({ archived_at: new Date().toISOString() })
      .eq("id", proof.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    setProofs((prev) => prev.filter((p) => p.id !== proof.id));
    toast.success("Proof archived");
  };

  const handleDelete = async (proof: Proof) => {
    const { error: storageErr } = await supabase.storage.from("proofs").remove([proof.image_path]);
    if (storageErr) {
      // continue even if storage removal fails (file may be missing)
      console.warn("Storage removal warning:", storageErr.message);
    }
    const { error } = await supabase.from("proofs").delete().eq("id", proof.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    setProofs((prev) => prev.filter((p) => p.id !== proof.id));
    toast.success("Proof deleted");
  };

  if (authLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <AppHeader />
      <main className="container py-10">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">Your proofs</h1>
            <p className="text-muted-foreground mt-1">Upload designs and collect feedback in one place.</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="lg" asChild>
              <Link to="/teams">
                <Users className="w-4 h-4 mr-2" /> Teams
              </Link>
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link to="/archive">
                <ArchiveIcon className="w-4 h-4 mr-2" /> Archive
              </Link>
            </Button>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button size="lg" className="shadow-elegant">
                  <Plus className="w-4 h-4 mr-2" /> New proof
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Upload a new proof</DialogTitle>
                </DialogHeader>
                <NewProofForm
                  onCreated={() => {
                    setOpen(false);
                    fetchProofs();
                  }}
                />
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {!loading && proofs.length > 0 && (
          <div className="flex flex-wrap items-center gap-3 mb-6">
            <div className="relative flex-1 min-w-[220px] max-w-md">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search proofs..."
                className="pl-9 h-9"
              />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Filter</span>
              <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as StatusFilter)}>
                <SelectTrigger className="w-[180px] h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="pending">Pending review</SelectItem>
                  <SelectItem value="changes_requested">Changes requested</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Sort</span>
              <Select value={sortKey} onValueChange={(v) => setSortKey(v as SortKey)}>
                <SelectTrigger className="w-[220px] h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="status">Status (approved first)</SelectItem>
                  <SelectItem value="newest">Date created (newest)</SelectItem>
                  <SelectItem value="oldest">Date created (oldest)</SelectItem>
                  <SelectItem value="alphabetical">Alphabetical (A–Z)</SelectItem>
                </SelectContent>
            </Select>
            </div>
            {uniqueOwners.length > 1 && (
              <div className="flex items-center gap-2">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" size="sm" className="h-9">
                      <Filter className="w-4 h-4 mr-2" />
                      Owners{ownerFilter.length > 0 ? ` (${ownerFilter.length})` : ""}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-64 p-2">
                    <div className="flex items-center justify-between px-2 py-1.5">
                      <span className="text-xs font-medium text-muted-foreground">Show proofs by</span>
                      {ownerFilter.length > 0 && (
                        <button
                          className="text-xs text-primary hover:underline"
                          onClick={() => setOwnerFilter([])}
                        >
                          Clear
                        </button>
                      )}
                    </div>
                    <ul className="max-h-64 overflow-y-auto">
                      {uniqueOwners.map((o) => {
                        const checked = ownerFilter.includes(o.id);
                        const label = o.id === user?.id ? "You" : (o.display_name || o.email || "Unknown");
                        return (
                          <li key={o.id}>
                            <label className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-accent cursor-pointer">
                              <Checkbox
                                checked={checked}
                                onCheckedChange={(v) => {
                                  setOwnerFilter((prev) =>
                                    v ? [...prev, o.id] : prev.filter((x) => x !== o.id)
                                  );
                                }}
                              />
                              <span className="text-sm truncate">{label}</span>
                            </label>
                          </li>
                        );
                      })}
                    </ul>
                  </PopoverContent>
                </Popover>
              </div>
            )}
            <div className="flex items-center gap-2 ml-auto">
              <span className="text-sm text-muted-foreground">View</span>
              <ToggleGroup type="single" value={viewMode} onValueChange={(v) => v && setViewMode(v as ViewMode)}>
                <ToggleGroupItem value="grid" aria-label="Grid view">
                  <LayoutGrid className="w-4 h-4" />
                </ToggleGroupItem>
                <ToggleGroupItem value="compact" aria-label="Compact view">
                  <Grid2X2 className="w-4 h-4" />
                </ToggleGroupItem>
                <ToggleGroupItem value="list" aria-label="List view">
                  <List className="w-4 h-4" />
                </ToggleGroupItem>
              </ToggleGroup>
            </div>
          </div>
        )}

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : proofs.length === 0 ? (
          <Card className="p-16 text-center border-dashed">
            <div className="w-14 h-14 rounded-full bg-accent flex items-center justify-center mx-auto mb-4">
              <ImagePlus className="w-7 h-7 text-accent-foreground" />
            </div>
            <h2 className="text-lg font-semibold mb-1">No proofs yet</h2>
            <p className="text-muted-foreground mb-6">Upload your first design to start collecting feedback.</p>
            <Button onClick={() => setOpen(true)}>
              <Plus className="w-4 h-4 mr-2" /> Create your first proof
            </Button>
          </Card>
        ) : visibleProofs.length === 0 ? (
          <Card className="p-16 text-center border-dashed">
            <p className="text-muted-foreground">No proofs match this filter.</p>
          </Card>
        ) : viewMode === "list" ? (
          <Card className="border-border/60 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[80px]">Preview</TableHead>
                  <TableHead>Title</TableHead>
                  <TableHead>Owner</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Last action</TableHead>
                  <TableHead className="w-[120px] text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {visibleProofs.map((p) => (
                  <TableRow key={p.id} className="cursor-pointer" onClick={() => navigate(`/proofs/${p.id}`)}>
                    <TableCell>
                      {isPdfUrl(p.image_url) ? (
                        <div className="w-16 h-10 rounded bg-muted flex items-center justify-center">
                          <FileText className="w-5 h-5 text-muted-foreground" />
                        </div>
                      ) : (
                        <img src={p.image_url} alt={p.title} className="w-16 h-10 object-cover rounded" loading="lazy" />
                      )}
                    </TableCell>
                    <TableCell className="font-medium">{p.title}</TableCell>
                    <TableCell className="text-sm">
                      {p.owner_id === user?.id ? "You" : (ownerProfiles[p.owner_id]?.display_name || ownerProfiles[p.owner_id]?.email || "—")}
                    </TableCell>
                    <TableCell><StatusBadge status={p.status} /></TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {format(new Date(p.created_at), "MMM d, yyyy 'at' h:mm a")}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {p.status !== "pending" && p.status_changed_at ? (
                        <>
                          {p.status === "approved" ? "Approved" : "Changes requested"}
                          {p.status_changed_by ? ` by ${p.status_changed_by}` : ""} · {format(new Date(p.status_changed_at), "MMM d, yyyy 'at' h:mm a")}
                        </>
                      ) : (
                        <span className="text-muted-foreground/50">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                      {p.owner_id === user?.id ? (
                        <div className="flex justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Archive proof" onClick={() => handleArchive(p)}>
                            <ArchiveIcon className="w-4 h-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Delete proof">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete this proof?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  "{p.title}" and all its comments will be permanently removed. This cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDelete(p)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      ) : null}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        ) : (
          <div className={
            viewMode === "compact"
              ? "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3"
              : "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5"
          }>
            {visibleProofs.map((p) => (
              <Card key={p.id} className="overflow-hidden group hover:shadow-elegant transition-smooth border-border/60 h-full relative">
                <Link to={`/proofs/${p.id}`} className="block">
                  <div className="aspect-video bg-muted overflow-hidden flex items-center justify-center">
                    {isPdfUrl(p.image_url) ? (
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <FileText className={viewMode === "compact" ? "w-7 h-7" : "w-10 h-10"} />
                        <span className="text-xs font-medium">PDF document</span>
                      </div>
                    ) : (
                      <img
                        src={p.image_url}
                        alt={p.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-smooth"
                        loading="lazy"
                      />
                    )}
                  </div>
                  <div className={viewMode === "compact" ? "p-2.5" : "p-4"}>
                    <div className={`flex items-start justify-between gap-2 ${viewMode === "compact" ? "mb-1" : "mb-2"}`}>
                      <h3 className={`${viewMode === "compact" ? "text-sm" : ""} font-medium tracking-tight line-clamp-1`}>{p.title}</h3>
                      <StatusBadge status={p.status} />
                    </div>
                    {viewMode === "compact" ? (
                      <p className="text-[11px] text-muted-foreground">
                        {format(new Date(p.created_at), "MMM d, yyyy")}
                      </p>
                    ) : (
                      <>
                        <p className="text-xs text-muted-foreground">
                          By {p.owner_id === user?.id ? "you" : (ownerProfiles[p.owner_id]?.display_name || ownerProfiles[p.owner_id]?.email || "—")}
                        </p>
                        <p className="text-xs text-muted-foreground mt-0.5" title={format(new Date(p.created_at), "PPpp")}>
                          Created {format(new Date(p.created_at), "MMM d, yyyy 'at' h:mm a")} · {formatDistanceToNow(new Date(p.created_at), { addSuffix: true })}
                        </p>
                        {p.status !== "pending" && p.status_changed_at && (
                          <p className="text-xs text-muted-foreground mt-1">
                            {p.status === "approved" ? "Approved" : "Changes requested"}
                            {p.status_changed_by ? ` by ${p.status_changed_by}` : ""} · {format(new Date(p.status_changed_at), "MMM d, yyyy 'at' h:mm a")}
                          </p>
                        )}
                      </>
                    )}
                  </div>
                </Link>
                {p.owner_id === user?.id && (
                <div className="absolute top-2 right-2 z-20 flex gap-2 opacity-0 group-hover:opacity-100 transition-smooth">
                  <Button
                    variant="secondary"
                    size="icon"
                    className="h-8 w-8 shadow-elegant"
                    aria-label="Archive proof"
                    onClick={() => handleArchive(p)}
                  >
                    <ArchiveIcon className="w-4 h-4" />
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="secondary"
                        size="icon"
                        className="h-8 w-8 shadow-elegant"
                        aria-label="Delete proof"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete this proof?</AlertDialogTitle>
                        <AlertDialogDescription>
                          "{p.title}" and all its comments will be permanently removed. This cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleDelete(p)}
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
                )}
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

type TeamMate = { user_id: string; email: string | null; display_name: string | null };

const NewProofForm = ({ onCreated }: { onCreated: () => void }) => {
  const { user } = useAuth();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [teamMates, setTeamMates] = useState<TeamMate[]>([]);
  const [selectedAssignees, setSelectedAssignees] = useState<string[]>([]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: myTeams } = await supabase.from("team_members").select("team_id").eq("user_id", user.id);
      const teamIds = (myTeams ?? []).map((t: any) => t.team_id);
      if (teamIds.length === 0) return;
      const { data: mems } = await supabase.from("team_members").select("user_id").in("team_id", teamIds);
      const ids = Array.from(new Set((mems ?? []).map((m: any) => m.user_id))).filter((u) => u !== user.id);
      if (ids.length === 0) return;
      const { data: profs } = await supabase.from("profiles").select("id, email, display_name").in("id", ids);
      setTeamMates((profs ?? []).map((p: any) => ({ user_id: p.id, email: p.email, display_name: p.display_name })));
    })();
  }, [user]);

  const addFiles = (incoming: FileList | null) => {
    if (!incoming) return;
    setFiles((prev) => [...prev, ...Array.from(incoming)]);
  };
  const removeFile = (idx: number) => setFiles((prev) => prev.filter((_, i) => i !== idx));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (files.length === 0 || !user) return;
    setUploading(true);
    try {
      const uploaded: { url: string; path: string }[] = [];
      for (const file of files) {
        const ext = file.name.split(".").pop();
        const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
        const { error: upErr } = await supabase.storage.from("proofs").upload(path, file);
        if (upErr) throw upErr;
        const { data: pub } = supabase.storage.from("proofs").getPublicUrl(path);
        uploaded.push({ url: pub.publicUrl, path });
      }
      const cover = uploaded[0];
      const { data: insertedProof, error: insErr } = await supabase
        .from("proofs")
        .insert({
          owner_id: user.id,
          title,
          description: description || null,
          image_url: cover.url,
          image_path: cover.path,
        })
        .select("id")
        .single();
      if (insErr) throw insErr;
      const proofId = insertedProof!.id as string;
      const { error: filesErr } = await supabase.from("proof_files").insert(
        uploaded.map((u, i) => ({ proof_id: proofId, image_url: u.url, image_path: u.path, position: i }))
      );
      if (filesErr) throw filesErr;
      if (selectedAssignees.length > 0) {
        await supabase.from("proof_assignees").insert(
          selectedAssignees.map((uid) => ({ proof_id: proofId, user_id: uid, assigned_by: user.id }))
        );
      }
      toast.success(files.length > 1 ? `${files.length} files uploaded` : "Proof created");
      onCreated();
    } catch (err: any) {
      toast.error(err.message ?? "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 mt-2">
      <div className="space-y-2">
        <Label htmlFor="title">Title</Label>
        <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} required placeholder="Homepage hero v2" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="desc">Description (optional)</Label>
        <Textarea id="desc" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Notes for reviewers..." rows={3} />
      </div>
      <div className="space-y-2">
        <Label htmlFor="file">Images or PDFs</Label>
        <label
          htmlFor="file"
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragOver(false);
            const dropped = Array.from(e.dataTransfer.files).filter(
              (f) => f.type.startsWith("image/") || f.type === "application/pdf"
            );
            if (dropped.length > 0) setFiles((prev) => [...prev, ...dropped]);
          }}
          className={`flex flex-col items-center justify-center border-2 border-dashed rounded-lg p-6 cursor-pointer transition-smooth ${
            dragOver ? "border-primary bg-accent/60" : "border-border hover:bg-accent/50"
          }`}
        >
          <Upload className="w-6 h-6 text-muted-foreground mb-2" />
          <span className="text-sm text-muted-foreground">
            {dragOver
              ? "Drop files here"
              : files.length === 0
                ? "Click or drag and drop images or PDFs here"
                : `Add more (${files.length} selected) — click or drop`}
          </span>
          <input
            id="file"
            type="file"
            accept="image/*,application/pdf"
            multiple
            className="hidden"
            onChange={(e) => {
              addFiles(e.target.files);
              e.target.value = "";
            }}
          />
        </label>
        {files.length > 0 && (
          <ul className="space-y-1.5 max-h-40 overflow-y-auto">
            {files.map((f, i) => (
              <li key={i} className="flex items-center gap-2 text-sm bg-muted/40 rounded px-2 py-1.5">
                <span className="truncate flex-1">{f.name}</span>
                <button
                  type="button"
                  onClick={() => removeFile(i)}
                  className="text-muted-foreground hover:text-destructive"
                  aria-label="Remove file"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
      {teamMates.length > 0 && (
        <div className="space-y-2">
          <Label>Assign teammates (optional)</Label>
          <div className="border rounded-md p-2 max-h-40 overflow-y-auto space-y-1">
            {teamMates.map((m) => {
              const checked = selectedAssignees.includes(m.user_id);
              return (
                <label key={m.user_id} className="flex items-center gap-2 px-2 py-1 rounded hover:bg-accent cursor-pointer">
                  <Checkbox
                    checked={checked}
                    onCheckedChange={(v) =>
                      setSelectedAssignees((prev) =>
                        v ? [...prev, m.user_id] : prev.filter((x) => x !== m.user_id)
                      )
                    }
                  />
                  <span className="text-sm truncate">{m.display_name || m.email}</span>
                </label>
              );
            })}
          </div>
        </div>
      )}
      <Button type="submit" className="w-full" disabled={uploading || files.length === 0}>
        {uploading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
        {files.length > 1 ? `Create proof with ${files.length} files` : "Create proof"}
      </Button>
    </form>
  );
};

export default Dashboard;
